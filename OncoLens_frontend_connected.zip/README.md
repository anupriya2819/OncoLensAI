# OncoLens AI — Frontend

Frontend-only React/TanStack Router application for the OncoLens AI pathology decision-support prototype.

## Architecture

The browser owns UI, routing, client-side validation, temporary frontend state, loading/error states, and rendering backend results.

AI inference, image quality assessment, Grad-CAM generation, biomarker analysis, persistence, authentication, reporting, and other server-side work belong to the backend.

API calls are centralized under `src/api/`.

## Run locally

```bash
npm install
npm run dev
```

Create `.env` from `.env.example` and set:

```env
VITE_API_BASE_URL=https://your-backend.example.com
```

## Backend handoff

See `BACKEND_HANDOFF.md` for the API contract, request fields, response fields, endpoint locations, and the small set of frontend files that should normally need changes when connecting the backend.

## Important

There is no model inference, Supabase integration, database persistence, or fake processing pipeline in this frontend build. The application waits for real API responses.

The patient/case store is intentionally in-memory for UI continuity while the backend is being connected. It should be replaced or synchronized with backend CRUD/auth endpoints when those are available.
