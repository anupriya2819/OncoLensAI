# OncoLens AI — Backend Handoff

## 1. Frontend scope

This repository is a frontend-only React application.

The frontend is responsible for:
- UI/UX and routing
- client-side file selection and validation
- temporary UI state
- loading and error states
- rendering API responses

The backend is responsible for:
- authentication/authorization
- patient and case persistence
- image quality assessment
- H&E/whole-slide inference
- benign/malignant classification
- confidence/risk
- Grad-CAM/heatmap generation
- ROI detection
- HER2, Ki-67 and other biomarker outputs
- clinical summary generation
- report generation/storage
- AI assistant responses

No local model inference or generated prediction values remain in the frontend.

## 2. Configure the backend URL

Create `.env` from `.env.example`:

```env
VITE_API_BASE_URL=https://your-backend.example.com
```

The API base URL is used by `src/api/client.ts`.

## 3. API endpoint configuration

If your routes differ, update only:

`src/api/endpoints.ts`

Current placeholders:

| Feature | Method | Frontend path |
|---|---|---|
| Image quality | POST | `/v1/analysis/quality` |
| Analysis | POST | `/v1/analysis` |
| Assistant | POST | `/v1/assistant` |
| Report | GET | `/v1/reports/:reportId` |

These paths are placeholders and must be verified against the actual backend.

## 4. Image quality request

`POST /v1/analysis/quality`

Content-Type: `multipart/form-data`

Field:

- `image`: uploaded pathology image file

Expected response:

```json
{
  "metrics": [
    {
      "label": "Resolution",
      "value": 95,
      "unit": "%",
      "ok": true
    }
  ],
  "passed": true
}
```

The frontend currently validates that `metrics` is an array and renders the returned values.

## 5. Analysis request

`POST /v1/analysis`

Content-Type: `multipart/form-data`

Fields:

- `image`: pathology image file
- `sampleId`: string
- `patientId`: string
- `clinicalHistory`: string
- `priority`: `Routine | Urgent | Critical`
- `doctor`: string

Expected response:

```json
{
  "diagnosis": "string",
  "confidence": 0,
  "risk": "Low | Moderate | High",
  "findings": ["string"],
  "biomarkers": [
    {
      "name": "HER2",
      "priority": "High | Medium | Low",
      "confidence": 0,
      "recommendation": "string",
      "rationale": "string"
    }
  ],
  "rois": [
    {
      "x": 0,
      "y": 0,
      "w": 0,
      "h": 0,
      "score": 0
    }
  ],
  "heatmapUrl": "https://...",
  "summary": "string",
  "ihcCost": 0,
  "savings": 0,
  "processingSeconds": 0,
  "reportId": "string",
  "completedAt": "ISO-8601 timestamp"
}
```

### Required fields

At minimum the frontend currently requires:

- `diagnosis`
- numeric `confidence`

The following arrays should be returned as arrays, even if empty:

- `findings`
- `biomarkers`
- `rois`

### Optional fields

The frontend handles these as optional:

- `heatmapUrl`
- `ihcCost`
- `savings`
- `processingSeconds`
- `reportId`
- `completedAt`

If `heatmapUrl` is absent, the UI displays the original slide and tells the user that the backend has not returned a Grad-CAM image.

## 6. Heatmap and ROI coordinate system

The frontend expects ROI coordinates as percentages of the displayed image:

- `x`: left position, 0–100
- `y`: top position, 0–100
- `w`: width, 0–100
- `h`: height, 0–100
- `score`: ROI score

The Grad-CAM output should be supplied as an image URL in `heatmapUrl`.

The frontend no longer generates a synthetic heatmap.

The backend should ideally return a heatmap aligned to the original image dimensions/aspect ratio.

## 7. Assistant API

`POST /v1/assistant`

JSON body:

```json
{
  "question": "Why was HER2 prioritised?",
  "caseId": "case-id",
  "reportId": "report-id"
}
```

Expected response:

```json
{
  "answer": "Backend-generated explanation..."
}
```

The frontend does not generate assistant answers locally.

## 8. Reports

The current report page remains a frontend presentation/print surface.

If the backend exposes a report API, connect it through:

`src/api/reportApi.ts`

The endpoint placeholder is:

`GET /v1/reports/:reportId`

If the backend instead returns a PDF URL or binary PDF, update the report service accordingly.

## 9. Authentication

Authentication is intentionally not implemented as a real backend integration in this handoff build.

The login screen currently creates a temporary frontend session so that the UI can be navigated without a server.

For production/backend integration:

1. Add the real authentication API.
2. Replace the temporary `login()` implementation in `src/lib/oncolens/store.tsx`.
3. Persist/refresh the authenticated session using the backend's mechanism.
4. Add authorization handling for protected API requests in `src/api/client.ts`.
5. Do not put secrets or service credentials in the frontend.

## 10. Patient and case CRUD

The current store is intentionally in-memory.

Relevant frontend functions:

- `addPatient`
- `updatePatient`
- `addCase`
- `updateCase`
- `log`

When the backend CRUD APIs are ready, replace these operations or synchronize them with API calls.

Do not store sensitive patient records permanently in browser local storage.

## 11. Error responses

Prefer a JSON error shape such as:

```json
{
  "message": "Human-readable error message",
  "code": "OPTIONAL_MACHINE_CODE"
}
```

The frontend reads `message` when available.

Recommended status codes:

- `400` invalid request
- `401` unauthenticated
- `403` unauthorized
- `404` resource not found
- `413` image too large
- `422` validation/model input error
- `500` server/model failure
- `503` model service unavailable

## 12. CORS

The backend must allow requests from the deployed frontend origin.

Do not add insecure frontend CORS workarounds.

If credentials/cookies are required, configure the API client and backend CORS policy together.

## 13. Environment variables

Frontend:

```env
VITE_API_BASE_URL=
```

Do not place private API keys, database passwords, model credentials, or service-role credentials in `VITE_*` variables.

Vite exposes `VITE_*` variables to browser code.

## 14. Main files for backend connection

Normally the backend developer should only need to inspect/modify:

- `src/api/client.ts`
- `src/api/endpoints.ts`
- `src/api/predictionApi.ts`
- `src/api/assistantApi.ts`
- `src/api/reportApi.ts`
- `.env`
- `src/lib/oncolens/store.tsx` for real auth/CRUD synchronization

The UI components should not need to be redesigned to connect the API.

## 15. Frontend run/build

```bash
npm install
npm run dev
```

Production build:

```bash
npm run build
```

The generated frontend is a browser application and contains no application server or Supabase dependency.

## 16. Important clinical/data note

OncoLens is a decision-support prototype. Backend/model responses must be validated by the clinical team before any clinical use. The frontend should display the backend's uncertainty and limitations rather than converting missing or uncertain values into positive/negative diagnoses.
