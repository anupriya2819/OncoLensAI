import { createFileRoute, Link } from "@tanstack/react-router";
import { PageHeader } from "@/components/oncolens/PageHeader";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useStore } from "@/lib/oncolens/store";

export const Route = createFileRoute("/app/history")({
    head: () => ({
      meta: [
         { title: "Case History — OncoLens AI" },
         {
            name: "description",
            content: "Chronological timeline of every analysed pathology case with slide, diagnosis and confidence.",
         },
         { property: "og:title", content: "Case History — OncoLens AI" },
         { property: "og:description", content: "Timeline of all previous AI-assisted pathology analyses." },
      ],
    }),
    component: HistoryPage,
});

function HistoryPage() {
    const { cases } = useStore();

    return (
      <>
         <PageHeader
            title="Case History"
            subtitle="Every analysis performed in this workspace, newest first, with the original uploaded slide preserved."
         />
         {cases.length === 0 ? (
            <Card className="glass rounded-2xl p-12 text-center">
              <p className="font-medium">No analyses yet</p>
              <Button asChild className="mt-4 rounded-xl">
                <Link to="/app/analysis" search={{ patientId: undefined }}>Run first analysis</Link>
              </Button>
            </Card>
         ) : (
            <div className="relative pl-6">
              <div className="bg-border absolute top-2 bottom-2 left-[7px] w-px" />
              <div className="space-y-5">
                {cases.map((c) => (
                  <div key={c.id} className="relative">
                    <span className="brand-gradient absolute top-6 -left-6 h-3.5 w-3.5 rounded-full ring-4 ring-background" />
                    <Card className="glass lift rounded-2xl p-5">
                      <div className="flex flex-wrap items-center gap-5">
                        <img
                           src={c.imageDataUrl}
                           alt={`Slide for ${c.sampleId}`}
                           className="h-24 w-24 rounded-2xl object-cover"
                        />
                        <div className="min-w-48 flex-1">
                           <div className="flex flex-wrap items-center gap-2">
                             <p className="font-display text-lg font-semibold">{c.sampleId}</p>
                             <Badge variant="outline" className="rounded-full">
                                {c.priority}
                             </Badge>
                           </div>
                           <p className="text-muted-foreground text-xs">
                             {c.patientName} · {new Date(c.createdAt).toLocaleString("en-IN")}
                           </p>
                           <p className="mt-2 text-sm font-medium">{c.result?.diagnosis}</p>
                           <p className="text-muted-foreground text-xs">
                             Confidence {c.result?.confidence}% · {c.result?.risk} risk · Report{" "}
                             {c.result?.reportId}
                           </p>
                        </div>
                        <div className="flex gap-2">
                           <Button asChild size="sm" variant="outline" className="rounded-xl">
                             <Link to="/app/reports/$caseId" params={{ caseId: c.id }}>
                                View Details
                             </Link>
                           </Button>
                           <Button asChild size="sm" className="rounded-xl">



                            <Link to="/app/reports/$caseId" params={{ caseId: c.id }}>
                               Download Report
                            </Link>
                          </Button>
                        </div>
                     </div>
                   </Card>
                 </div>
              ))}
            </div>
          </div>
       )}
     </>
  );
}




