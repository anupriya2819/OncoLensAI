import { createFileRoute } from "@tanstack/react-router";
import { Cloud, CheckCircle2 } from "lucide-react";
import { PageHeader } from "@/components/oncolens/PageHeader";
import { Card } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { useStore } from "@/lib/oncolens/store";

export const Route = createFileRoute("/app/storage")({
   head: () => ({
     meta: [
        { title: "Cloud Storage — OncoLens AI" },
        {
           name: "description",
           content: "Uploaded slides, generated heatmaps and reports with storage usage and sync status.",
        },
        { property: "og:title", content: "Cloud Storage — OncoLens AI" },
        { property: "og:description", content: "Slide, heatmap and report storage overview." },
     ],
   }),
   component: StoragePage,
});

function StoragePage() {
   const { cases } = useStore();
   const bytes = cases.reduce((a, c) => a + c.imageDataUrl.length * 0.75, 0);
   const mb = bytes / (1024 * 1024);
   const quota = 512;

   return (
     <>
        <PageHeader
           title="Cloud Storage"
           subtitle="Slides and reports are held in encrypted browser storage in this prototype, ready to migrate to managed cloud storage."
        />
        <div className="grid gap-5 lg:grid-cols-[1fr_2fr]">
           <Card className="glass h-fit rounded-2xl p-5">
             <div className="flex items-center gap-3">
               <div className="brand-gradient text-primary-foreground flex h-10 w-10 items-center justify-center rounded-2xl">
                 <Cloud className="h-5 w-5" strokeWidth={1.7} />
               </div>
               <div>
                 <p className="font-medium">Storage Usage</p>
                 <p className="text-muted-foreground text-xs">{mb.toFixed(2)} MB of {quota} MB</p>
               </div>
             </div>
             <Progress value={(mb / quota) * 100} className="mt-4 h-2" />
             <div className="text-success mt-4 flex items-center gap-2 text-sm">
               <CheckCircle2 className="h-4 w-4" /> Local vault synced
             </div>
             <div className="text-muted-foreground mt-4 space-y-1.5 text-sm">
               <p>Slides: {cases.length}</p>
               <p>Heatmaps: {cases.filter((c) => c.result).length}</p>
               <p>Reports: {cases.filter((c) => c.result).length}</p>
             </div>
           </Card>

           <Card className="glass rounded-2xl p-5">
             <h2 className="text-lg font-semibold">Stored Objects</h2>
             {cases.length === 0 ? (
               <p className="text-muted-foreground mt-3 text-sm">Nothing stored yet.</p>
             ) : (
               <div className="mt-4 grid gap-4 sm:grid-cols-3">
                 {cases.map((c) => (
                    <div key={c.id} className="lift overflow-hidden rounded-2xl border">
                      <img src={c.imageDataUrl} alt={`Stored slide ${c.sampleId}`} className="h-28 w-full object-cover" /
 >
                      <div className="p-3">
                        <p className="truncate text-sm font-medium">{c.imageName}</p>
                        <p className="text-muted-foreground text-xs">{c.sampleId}</p>
                        <Badge variant="outline" className="mt-2 rounded-full text-[10px]">
                           Encrypted
                        </Badge>
                      </div>
                    </div>



                ))}
              </div>
           )}
         </Card>
       </div>
     </>
  );
}




