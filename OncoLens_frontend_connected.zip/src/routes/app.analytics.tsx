import { createFileRoute } from "@tanstack/react-router";
import {
   Bar,
   BarChart,
   CartesianGrid,
   Cell,
   Line,
   LineChart,
   Pie,
   PieChart,
   ResponsiveContainer,
   Tooltip,
   XAxis,
   YAxis,
} from "recharts";
import { PageHeader } from "@/components/oncolens/PageHeader";
import { Card } from "@/components/ui/card";
import { useStore } from "@/lib/oncolens/store";

export const Route = createFileRoute("/app/analytics")({
   head: () => ({
     meta: [
        { title: "Analytics — OncoLens AI" },
        {
           name: "description",
           content: "Department analytics: case volume, diagnosis distribution, biomarker demand, confidence and IHC savings.",
        },
        { property: "og:title", content: "Analytics — OncoLens AI" },
        { property: "og:description", content: "Pathology throughput and cost analytics." },
     ],
   }),
   component: AnalyticsPage,
});

const COLORS = ["#3b6ef6", "#22b8c9", "#f59e0b", "#ef4444"];

function AnalyticsPage() {
   const { cases } = useStore();
   const done = cases.filter((c) => c.result);

   const months = Array.from({ length: 6 }, (_, i) => {
     const d = new Date();
     d.setMonth(d.getMonth() - (5 - i));
     const key = d.toLocaleString("en-IN", { month: "short" });
     const count = done.filter((c) => new Date(c.createdAt).getMonth() === d.getMonth()).length;
     const savings = done
        .filter((c) => new Date(c.createdAt).getMonth() === d.getMonth())
        .reduce((a, c) => a + (c.result?.savings ?? 0), 0);
     return { month: key, cases: count, savings };
   });

   const diagnosis = Object.entries(
     done.reduce<Record<string, number>>((acc, c) => {
        const k = c.result!.risk;
        acc[k] = (acc[k] ?? 0) + 1;
        return acc;
     }, {}),
   ).map(([name, value]) => ({ name, value }));

   const markers = ["HER2", "Ki-67", "ER", "PR"].map((name) => ({
     name,
     count: done.filter((c) => c.result!.biomarkers.some((b) => b.name === name && b.priority !== "Low"))
        .length,
   }));

   const confidence = done
     .slice()
     .reverse()
     .map((c, i) => ({ n: `#${i + 1}`, confidence: c.result!.confidence }));

   const avgTurnaround = done.length
     ? (done.reduce((a, c) => a + (c.result?.processingSeconds ?? 0), 0) / done.length).toFixed(1)
     : "0.0";

   return (
     <>



    <PageHeader title="Analytics" subtitle="Operational and economic impact of AI-assisted triage." />
    {done.length === 0 ? (
      <Card className="glass rounded-2xl p-12 text-center">
        <p className="font-medium">No analysed cases yet</p>
        <p className="text-muted-foreground mt-1 text-sm">Charts populate after your first analysis.</p>
      </Card>
    ) : (
      <div className="grid gap-5 lg:grid-cols-2">
        <Card className="glass rounded-2xl p-5">
          <h2 className="mb-4 text-lg font-semibold">Cases per Month</h2>
          <ResponsiveContainer width="100%" height={240}>
            <BarChart data={months}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} />
              <XAxis dataKey="month" fontSize={12} />
              <YAxis allowDecimals={false} fontSize={12} />
              <Tooltip />
              <Bar dataKey="cases" fill="#3b6ef6" radius={[8, 8, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </Card>

        <Card className="glass rounded-2xl p-5">
          <h2 className="mb-4 text-lg font-semibold">Risk Distribution</h2>
          <ResponsiveContainer width="100%" height={240}>
            <PieChart>
              <Pie data={diagnosis} dataKey="value" nameKey="name" innerRadius={55} outerRadius={90}>
                {diagnosis.map((_, i) => (
                  <Cell key={i} fill={COLORS[i % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </Card>

        <Card className="glass rounded-2xl p-5">
          <h2 className="mb-4 text-lg font-semibold">Biomarker Recommendations</h2>
          <ResponsiveContainer width="100%" height={240}>
            <BarChart data={markers} layout="vertical">
              <CartesianGrid strokeDasharray="3 3" horizontal={false} />
              <XAxis type="number" allowDecimals={false} fontSize={12} />
              <YAxis type="category" dataKey="name" fontSize={12} width={60} />
              <Tooltip />
              <Bar dataKey="count" fill="#22b8c9" radius={[0, 8, 8, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </Card>

        <Card className="glass rounded-2xl p-5">
          <h2 className="mb-4 text-lg font-semibold">Average Confidence Trend</h2>
          <ResponsiveContainer width="100%" height={240}>
            <LineChart data={confidence}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} />
              <XAxis dataKey="n" fontSize={12} />
              <YAxis domain={[50, 100]} fontSize={12} />
              <Tooltip />
              <Line type="monotone" dataKey="confidence" stroke="#3b6ef6" strokeWidth={2.5} dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </Card>

        <Card className="glass rounded-2xl p-5 lg:col-span-2">
          <h2 className="mb-4 text-lg font-semibold">Estimated IHC Savings (₹) &amp; Turnaround</h2>
          <p className="text-muted-foreground mb-3 text-sm">
             Average AI turnaround: <span className="text-foreground font-medium">{avgTurnaround}s</span> per slide
          </p>
          <ResponsiveContainer width="100%" height={240}>
             <BarChart data={months}>
               <CartesianGrid strokeDasharray="3 3" vertical={false} />
               <XAxis dataKey="month" fontSize={12} />
               <YAxis fontSize={12} />
               <Tooltip formatter={(v) => `₹${Number(v).toLocaleString("en-IN")}`} />
               <Bar dataKey="savings" fill="#22b8c9" radius={[8, 8, 0, 0]} />
             </BarChart>
          </ResponsiveContainer>
        </Card>
      </div>



       )}
     </>
  );
}




