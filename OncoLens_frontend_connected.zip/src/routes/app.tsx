import { createFileRoute, Outlet } from "@tanstack/react-router";
import { AppShell } from "@/components/oncolens/AppShell";

export const Route = createFileRoute("/app")({
  component: () => (
     <AppShell>
       <Outlet />
     </AppShell>
  ),
});




