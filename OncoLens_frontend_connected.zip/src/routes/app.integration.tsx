import { createFileRoute } from "@tanstack/react-router";
import { Building2, Network, Database, FileCode2 } from "lucide-react";
import { PageHeader } from "@/components/oncolens/PageHeader";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

export const Route = createFileRoute("/app/integration")({
   head: () => ({
      meta: [
         { title: "Hospital Integration — OncoLens AI" },
         {
            name: "description",
            content: "Planned HIS, LIS, digital pathology and FHIR integrations with partner hospitals.",
         },
         { property: "og:title", content: "Hospital Integration — OncoLens AI" },
         { property: "og:description", content: "HIS, LIS, digital pathology and FHIR integration roadmap." },
      ],
   }),
   component: IntegrationPage,
});

const HOSPITALS = [
   "Apex Institute of Oncology, Bengaluru",
   "Sanjeevani Cancer Centre, Pune",
   "Meridian Multispeciality Hospital, Hyderabad",
   "Nightingale Diagnostics Network, Chennai",
];

const SYSTEMS = [
   { icon: Network, name: "HIS", desc: "Hospital Information System — patient demographics and encounters" },
   { icon: Database, name: "LIS", desc: "Laboratory Information System — sample accessioning and results" },
   { icon: Building2, name: "Digital Pathology", desc: "Whole-slide scanner ingestion (SVS, NDPI)" },
   { icon: FileCode2, name: "HL7 FHIR", desc: "Standards-based interoperability for reports and observations" },
];

function IntegrationPage() {
   return (
      <>
         <PageHeader
            title="Hospital Integration"
            subtitle="OncoLens AI is designed to sit alongside existing hospital systems rather than replace them."
         />
         <div className="grid gap-5 lg:grid-cols-2">
            <Card className="glass rounded-2xl p-5">
              <h2 className="text-lg font-semibold">Partner Hospitals</h2>
              <div className="mt-4 space-y-3">
                {HOSPITALS.map((h) => (
                  <div key={h} className="flex items-center justify-between rounded-xl border p-3">
                     <p className="text-sm font-medium">{h}</p>
                     <Badge variant="outline" className="rounded-full">
                       Under Development
                     </Badge>
                  </div>
                ))}
              </div>
            </Card>
            <Card className="glass rounded-2xl p-5">
              <h2 className="text-lg font-semibold">Planned Interfaces</h2>
              <div className="mt-4 grid gap-3 sm:grid-cols-2">
                {SYSTEMS.map((s) => (
                  <div key={s.name} className="lift rounded-2xl border p-4">
                     <div className="bg-accent text-accent-foreground flex h-9 w-9 items-center justify-center rounded-xl"
 >
                       <s.icon className="h-[18px] w-[18px]" strokeWidth={1.7} />
                     </div>
                     <p className="mt-3 font-medium">{s.name}</p>
                     <p className="text-muted-foreground mt-1 text-xs/5">{s.desc}</p>
                     <Badge variant="secondary" className="mt-3 rounded-full text-[10px]">
                       Roadmap
                     </Badge>
                  </div>
                ))}
              </div>
            </Card>
         </div>
      </>
   );



}




