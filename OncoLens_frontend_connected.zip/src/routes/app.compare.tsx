import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { PageHeader } from "@/components/oncolens/PageHeader";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
   Select,
   SelectContent,
   SelectItem,
   SelectTrigger,
   SelectValue,
} from "@/components/ui/select";
import { HeatmapImage } from "@/components/oncolens/HeatmapImage";
import { useStore } from "@/lib/oncolens/store";

export const Route = createFileRoute("/app/compare")({
   head: () => ({
     meta: [
        { title: "Compare Reports — OncoLens AI" },
        {
           name: "description",
           content: "Side-by-side comparison of two pathology reports: images, heatmaps, diagnosis, confidence and biomarkers.",
        },
        { property: "og:title", content: "Compare Reports — OncoLens AI" },
        { property: "og:description", content: "Compare two AI-assisted pathology reports side by side." },
     ],
   }),
   component: ComparePage,
});

function ComparePage() {
   const { cases } = useStore();
   const done = cases.filter((c) => c.result);
   const [a, setA] = useState(done[0]?.id ?? "");
   const [b, setB] = useState(done[1]?.id ?? "");
   const left = done.find((c) => c.id === a);
   const right = done.find((c) => c.id === b);

   return (
     <>
        <PageHeader
           title="Compare Reports"
           subtitle="Select two completed cases to compare imaging, AI impression, confidence and recommended biomarkerpanels."
        />

        {done.length < 2 ? (
           <Card className="glass rounded-2xl p-12 text-center">
              <p className="font-medium">At least two completed reports are required</p>
              <p className="text-muted-foreground mt-1 text-sm">
                Run another analysis to unlock comparison.
              </p>
           </Card>
        ) : (
           <>
              <div className="mb-5 grid gap-4 md:grid-cols-2">
                {[
                   { value: a, set: setA, label: "Report A" },
                   { value: b, set: setB, label: "Report B" },
                ].map((s) => (
                   <div key={s.label}>
                     <p className="text-muted-foreground mb-2 text-xs uppercase">{s.label}</p>
                     <Select value={s.value} onValueChange={s.set}>
                       <SelectTrigger className="glass rounded-xl">
                          <SelectValue />
                       </SelectTrigger>
                       <SelectContent>
                          {done.map((c) => (
                            <SelectItem key={c.id} value={c.id}>
                              {c.result!.reportId} · {c.patientName}
                            </SelectItem>
                          ))}
                       </SelectContent>
                     </Select>
                   </div>



               ))}
            </div>

            <div className="grid gap-5 md:grid-cols-2">
               {[left, right].map((c, i) =>
                  c ? (
                    <Card key={c.id + i} className="glass space-y-4 rounded-2xl p-5">
                       <div className="flex items-center justify-between">
                          <p className="font-display font-semibold">{c.result!.reportId}</p>
                          <Badge variant="outline" className="rounded-full">
                             {c.result!.risk} risk
                          </Badge>
                       </div>
                       <img
                          src={c.imageDataUrl}
                          alt={`Original slide ${c.sampleId}`}
                          className="w-full rounded-xl"
                       />
                       <HeatmapImage src={c.imageDataUrl} heatmapSrc={c.result!.heatmapUrl} rois={c.result!.rois} />
                       <div>
                          <p className="text-sm font-medium">{c.result!.diagnosis}</p>
                          <Progress value={c.result!.confidence} className="mt-2 h-2" />
                          <p className="text-muted-foreground mt-1 text-xs">
                             {c.result!.confidence}% confidence · {new Date(c.createdAt).toLocaleDateString("en-IN")}
                          </p>
                       </div>
                       <div className="flex flex-wrap gap-2">
                          {c.result!.biomarkers.map((m) => (
                             <Badge key={m.name} variant="secondary" className="rounded-full">
                               {m.name} · {m.priority} · {m.confidence}%
                             </Badge>
                          ))}
                       </div>
                    </Card>
                  ) : null,
               )}
            </div>

            {left && right && (
               <Card className="glass mt-5 rounded-2xl p-5">
                  <h2 className="text-lg font-semibold">Timeline &amp; Delta</h2>
                  <div className="mt-4 space-y-3 text-sm">
                    <Delta
                       label="Confidence change"
                       value={`${(right.result!.confidence - left.result!.confidence).toFixed(1)} pts`}
                    />
                    <Delta
                       label="Interval between cases"
                       value={`${Math.abs(
                          Math.round(
                             (new Date(right.createdAt).getTime() - new Date(left.createdAt).getTime()) /
                               86400000,
                          ),
                       )} day(s)`}
                    />
                    <Delta
                       label="Diagnosis"
                       value={
                          left.result!.diagnosis === right.result!.diagnosis
                             ? "Concordant"
                             : "Discordant — pathologist review advised"
                       }
                    />
                    <Delta
                       label="Top biomarker"
                       value={`${left.result!.biomarkers[0]!.name} → ${right.result!.biomarkers[0]!.name}`}
                    />
                  </div>
               </Card>
            )}
          </>
       )}
     </>
  );
}

function Delta({ label, value }: { label: string; value: string }) {



  return (
     <div className="flex justify-between border-b border-dashed pb-2 last:border-0">
       <span className="text-muted-foreground">{label}</span>
       <span className="font-medium">{value}</span>
     </div>
  );
}




