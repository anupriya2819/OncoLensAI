import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { Search, Printer, Download, Eye } from "lucide-react";
import { PageHeader } from "@/components/oncolens/PageHeader";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useStore } from "@/lib/oncolens/store";

export const Route = createFileRoute("/app/reports/")({
   head: () => ({
     meta: [
        { title: "Reports — OncoLens AI" },
        {
           name: "description",
           content: "Search, preview, print and download hospital-format pathology decision support reports.",
        },
        { property: "og:title", content: "Reports — OncoLens AI" },
        { property: "og:description", content: "All generated pathology reports in one place." },
     ],
   }),
   component: ReportsPage,
});

function ReportsPage() {
   const { cases } = useStore();
   const [q, setQ] = useState("");
   const [risk, setRisk] = useState<"All" | "Low" | "Moderate" | "High">("All");
   const term = q.trim().toLowerCase();

   const list = cases.filter((c) => {
     if (!c.result) return false;
     if (risk !== "All" && c.result.risk !== risk) return false;
     return (
        !term ||
        c.sampleId.toLowerCase().includes(term) ||
        c.patientName.toLowerCase().includes(term) ||
        (c.result.reportId ?? "").toLowerCase().includes(term)
     );
   });

   return (
     <>
        <PageHeader title="Reports" subtitle="Hospital-format reports generated from completed analyses." />

        <div className="mb-5 flex flex-wrap items-center gap-3">
           <div className="relative max-w-sm flex-1">
             <Search className="text-muted-foreground pointer-events-none absolute top-1/2 left-3.5 h-4 w-4 -translate-y-1/2" />
             <input
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder="Search report ID, sample or patient"
                className="glass focus:ring-ring/40 w-full rounded-2xl py-3 pr-4 pl-10 text-sm outline-none focus:ring-2"
             />
           </div>
           {(["All", "Low", "Moderate", "High"] as const).map((r) => (
             <button
                key={r}
                onClick={() => setRisk(r)}
                className={`rounded-xl px-4 py-2 text-xs font-medium transition-colors ${
                  risk === r ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground hover:text-foreground"
                }`}
             >
                {r}
             </button>
           ))}
        </div>

        {list.length === 0 ? (
           <Card className="glass rounded-2xl p-12 text-center">
             <p className="font-medium">No reports found</p>
             <p className="text-muted-foreground mt-1 text-sm">Complete an analysis to generate a report.</p>
           </Card>
        ) : (
           <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">



            {list.map((c) => (
              <Card key={c.id} className="glass lift overflow-hidden rounded-2xl p-0">
                 <img src={c.imageDataUrl} alt={`Slide ${c.sampleId}`} className="h-36 w-full object-cover" />
                 <div className="p-5">
                   <div className="flex items-center justify-between">
                     <p className="font-display font-semibold">{c.result!.reportId}</p>
                     <Badge variant="outline" className="rounded-full">
                        {c.result!.risk}
                     </Badge>
                   </div>
                   <p className="text-muted-foreground mt-1 text-xs">
                     {c.patientName} · {c.sampleId}
                   </p>
                   <p className="mt-3 text-sm font-medium">{c.result!.diagnosis}</p>
                   <p className="text-muted-foreground text-xs">
                     {c.result!.confidence}% confidence ·{" "}
                     {new Date(c.createdAt).toLocaleDateString("en-IN")}
                   </p>
                   <div className="mt-4 flex gap-2">
                     <Button asChild size="sm" className="rounded-xl">
                        <Link to="/app/reports/$caseId" params={{ caseId: c.id }}>
                          <Eye className="mr-1 h-3.5 w-3.5" /> Preview
                        </Link>
                     </Button>
                     <Button asChild size="sm" variant="outline" className="rounded-xl">
                        <Link to="/app/reports/$caseId" params={{ caseId: c.id }}>
                          <Printer className="mr-1 h-3.5 w-3.5" /> Print
                        </Link>
                     </Button>
                     <Button asChild size="sm" variant="ghost" className="rounded-xl">
                        <Link to="/app/reports/$caseId" params={{ caseId: c.id }}>
                          <Download className="h-3.5 w-3.5" />
                        </Link>
                     </Button>
                   </div>
                 </div>
              </Card>
            ))}
          </div>
       )}
     </>
  );
}




