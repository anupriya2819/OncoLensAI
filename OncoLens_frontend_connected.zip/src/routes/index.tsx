import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { ShieldCheck, Lock, Sparkles, Activity, ArrowRight } from "lucide-react";
import { toast } from "sonner";
import { Brand } from "@/components/oncolens/Brand";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import {
   Select,
   SelectContent,
   SelectItem,
   SelectTrigger,
   SelectValue,
} from "@/components/ui/select";
import { useStore } from "@/lib/oncolens/store";
import type { Role } from "@/lib/oncolens/types";

const TITLE = "OncoLens AI — Breast Cancer Pathology Decision Support";
const DESC =
   "Secure hospital login for OncoLens AI: AI-assisted H&E slide analysis, IHC biomarker prioritisation and printablepathology reports.";

export const Route = createFileRoute("/")({
   head: () => ({
     meta: [
        { title: TITLE },
        { name: "description", content: DESC },
        { property: "og:title", content: TITLE },
        { property: "og:description", content: DESC },
        { property: "og:type", content: "website" },
        { name: "twitter:card", content: "summary_large_image" },
     ],
   }),
   component: LoginPage,
});

const ROLES: Role[] = ["Admin", "Pathologist", "Lab Technician", "Patient"];

function LoginPage() {
   const { login } = useStore();
   const navigate = useNavigate();
   const [email, setEmail] = useState("");
   const [password, setPassword] = useState("");
   const [role, setRole] = useState<Role>("Pathologist");
   const [remember, setRemember] = useState(true);
   const [loading, setLoading] = useState(false);

   function submit(e: React.FormEvent) {
     e.preventDefault();
     if (!email.trim() || !password.trim()) {
        toast.error("Enter your hospital credentials to continue.");
        return;
     }
     setLoading(true);
     login({
       name: role === "Patient" ? "Patient User" : "Pathology User",
       email,
       role,
       hospital: "Apex Institute of Oncology",
     });
     toast.success(`Workspace ready for ${role}`);
     navigate({ to: "/app/dashboard" });
     setLoading(false);
   }

   return (
     <div className="grid min-h-screen lg:grid-cols-[1.05fr_1fr]">
        <section className="relative hidden overflow-hidden lg:block">
          <div className="brand-gradient absolute inset-0" />
          <div className="absolute inset-0 opacity-25 [background:radial-gradient(28rem_20rem_at_20%_20%,white,transparent),radial-gradient(30rem_22rem_at_80%_70%,white,transparent)]" />
          <div className="text-primary-foreground relative flex h-full flex-col justify-between p-12">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-white/20 backdrop-blur">



            <Activity className="h-5 w-5" strokeWidth={1.7} />
          </div>
          <p className="font-display text-lg font-semibold">Apex Institute of Oncology</p>
        </div>

        <div className="max-w-lg">
          <h1 className="font-display text-4xl leading-tight font-semibold">
            Precision pathology, one lens ahead.
          </h1>
          <p className="mt-4 text-sm/6 text-white/85">
            OncoLens AI reads H&amp;E histopathology slides, highlights suspicious regions and
            prioritises the confirmatory IHC biomarkers that matter — so pathologists reach a
            confident diagnosis faster and hospitals spend less per case.
          </p>
          <div className="mt-8 grid gap-3 sm:grid-cols-3">
            {[
               { icon: Sparkles, label: "Explainable AI overlays" },
               { icon: ShieldCheck, label: "Role-based access" },
               { icon: Lock, label: "Encrypted case storage" },
            ].map((f) => (
               <div key={f.label} className="rounded-2xl bg-white/12 p-4 backdrop-blur">
                 <f.icon className="h-5 w-5" strokeWidth={1.7} />
                 <p className="mt-2.5 text-xs/5 font-medium">{f.label}</p>
               </div>
            ))}
          </div>
        </div>

        <p className="text-xs text-white/70">
          Decision support only. Final diagnosis remains with the pathologist.
        </p>
      </div>
    </section>

    <section className="flex items-center justify-center px-5 py-12 sm:px-10">
      <div className="w-full max-w-md">
        <Brand />
        <h2 className="mt-8 text-2xl font-semibold">Sign in to your workspace</h2>
        <p className="text-muted-foreground mt-1.5 text-sm">
          Use your hospital-issued credentials. Access is scoped to your role.
        </p>

        <form onSubmit={submit} className="mt-7 space-y-4">
          <div className="space-y-2">
            <Label htmlFor="role">Role</Label>
            <Select value={role} onValueChange={(v) => setRole(v as Role)}>
               <SelectTrigger id="role" className="rounded-xl">
                 <SelectValue />
               </SelectTrigger>
               <SelectContent>
                 {ROLES.map((r) => (
                   <SelectItem key={r} value={r}>
                     {r}
                   </SelectItem>
                 ))}
               </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label htmlFor="email">Hospital email</Label>
            <Input
               id="email"
               type="email"
               className="rounded-xl"
               value={email}
               onChange={(e) => setEmail(e.target.value)}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="password">Password</Label>
            <Input
               id="password"
               type="password"
               className="rounded-xl"
               value={password}
               onChange={(e) => setPassword(e.target.value)}
            />



              </div>
              <div className="flex items-center justify-between">
                 <label className="text-muted-foreground flex items-center gap-2 text-sm">
                   <Checkbox
                      checked={remember}
                      onCheckedChange={(v) => setRemember(Boolean(v))}
                   />
                   Remember me
                 </label>
                 <button
                   type="button"
                   onClick={() => toast.info("A reset link would be sent to your hospital email.")}
                   className="text-primary text-sm font-medium hover:underline"
                 >
                   Forgot password?
                 </button>
              </div>
              <Button type="submit" className="h-11 w-full rounded-xl" disabled={loading}>
                 {loading ? "Verifying…" : "Secure sign in"}
                 {!loading && <ArrowRight className="ml-1 h-4 w-4" />}
              </Button>
            </form>

            <p className="text-muted-foreground mt-6 text-xs/5">
              Patients can view only their own reports. Doctors can access only assigned patients.
              Sessions expire automatically after 20 minutes of inactivity.
            </p>
            <p className="text-muted-foreground mt-6 border-t pt-4 text-xs">
              Research &amp; Educational Use Only · Prototype v1.0 · Made by Team SKY
            </p>
         </div>
       </section>
     </div>
  );
}




