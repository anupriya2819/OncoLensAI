import { createFileRoute, Link, useParams } from "@tanstack/react-router";
import { Printer, Download, QrCode } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { HeatmapImage } from "@/components/oncolens/HeatmapImage";
import { useStore } from "@/lib/oncolens/store";

export const Route = createFileRoute("/app/reports/$caseId")({
   head: () => ({
     meta: [
        { title: "Pathology Report — OncoLens AI" },
        {
           name: "description",
           content:
             "Printable hospital-format AI decision support report with slide, heatmap, ROI, diagnosis, biomarkers and cost estimate.",
        },
        { property: "og:title", content: "Pathology Report — OncoLens AI" },
        { property: "og:description", content: "Printable AI-assisted pathology report." },
     ],
   }),
   component: ReportPage,
});

function ReportPage() {
   const { caseId } = useParams({ from: "/app/reports/$caseId" });
   const { cases, patients, log } = useStore();
   const record = cases.find((c) => c.id === caseId);
   const [notes, setNotes] = useState("");

   if (!record || !record.result) {
     return (
        <Card className="glass rounded-2xl p-12 text-center">
           <p className="font-medium">Report not available</p>
           <Button asChild className="mt-4 rounded-xl">
             <Link to="/app/reports">Back to reports</Link>
           </Button>
        </Card>
     );
   }

   const r = record.result;
   const patient = patients.find((p) => p.id === record.patientId);

   function print() {
     log(`Report downloaded — ${r.reportId}`);
     toast.success("Opening print dialog — choose 'Save as PDF' to download.");
     setTimeout(() => window.print(), 350);
   }

   return (
     <>
        <div className="no-print mb-5 flex flex-wrap items-center justify-between gap-3">
           <div>
             <h1 className="text-2xl font-semibold">Report {r.reportId}</h1>
             <p className="text-muted-foreground text-sm">
               Hospital-format, printable and downloadable as PDF.
             </p>
           </div>
           <div className="flex gap-2">
             <Button variant="outline" className="rounded-xl" onClick={print}>
               <Printer className="mr-1 h-4 w-4" /> Print
             </Button>
             <Button className="rounded-xl" onClick={print}>
               <Download className="mr-1 h-4 w-4" /> Download PDF
             </Button>
           </div>
        </div>

        <Card className="mx-auto max-w-4xl rounded-2xl border bg-card p-8 print:border-0 print:shadow-none">
           <header className="border-primary/30 flex flex-wrap items-start justify-between gap-4 border-b-2 pb-5">
             <div>
               <p className="font-display text-xl font-semibold">Apex Institute of Oncology</p>
               <p className="text-muted-foreground text-xs">



            Department of Histopathology · NABL accredited · Bengaluru, India
          </p>
        </div>
        <div className="text-right text-xs">
          <p className="font-display brand-text text-base font-semibold">OncoLens AI</p>
          <p className="text-muted-foreground">AI-Assisted Decision Support Report</p>
          <p className="text-muted-foreground">Report ID: {r.reportId}</p>
          <p className="text-muted-foreground">
            Generated: {new Date(r.completedAt ?? "").toLocaleString("en-IN")}
          </p>
        </div>
      </header>

      <section className="mt-6 grid gap-6 sm:grid-cols-2">
        <Block title="Patient Details">
          <Row k="Name" v={record.patientName} />
          <Row k="Patient ID" v={record.patientId} />
          <Row k="Hospital ID" v={patient?.hospitalId || "—"} />
          <Row k="Age / Gender" v={`${patient?.age ?? "—"} · ${patient?.gender ?? "—"}`} />
          <Row k="Referring Doctor" v={record.doctor} />
        </Block>
        <Block title="Sample Details">
          <Row k="Sample ID" v={record.sampleId} />
          <Row k="Stain" v="Haematoxylin &amp; Eosin (H&amp;E)" />
          <Row k="Priority" v={record.priority} />
          <Row k="Received" v={new Date(record.createdAt).toLocaleString("en-IN")} />
          <Row k="Clinical History" v={record.clinicalHistory || "Not provided"} />
        </Block>
      </section>

      <section className="mt-6">
        <SectionTitle>Slide Imaging &amp; Explainability</SectionTitle>
        <div className="mt-3 grid gap-4 sm:grid-cols-2">
          <figure>
            <img src={record.imageDataUrl} alt="Original H&E slide" className="w-full rounded-xl" />
            <figcaption className="text-muted-foreground mt-1.5 text-xs">
               Original uploaded H&amp;E slide — {record.imageName}
            </figcaption>
          </figure>
          <figure>
            <HeatmapImage src={record.imageDataUrl} heatmapSrc={r.heatmapUrl} rois={r.rois} />
            <figcaption className="text-muted-foreground mt-1.5 text-xs">
               Grad-CAM heatmap returned by the backend with {r.rois.length} regions of interest
            </figcaption>
          </figure>
        </div>
      </section>

      <section className="mt-6 grid gap-6 sm:grid-cols-2">
        <Block title="AI Impression">
          <Row k="Diagnosis" v={r.diagnosis} />
          <Row k="Confidence" v={`${r.confidence}%`} />
          <Row k="Risk Level" v={r.risk} />
          <Row k="Processing Time" v={r.processingSeconds != null ? `${r.processingSeconds}s` : "—"} />
        </Block>
        <Block title="Cost Estimate">
          <Row k="Prioritised IHC Panel" v={r.ihcCost != null ? `₹${r.ihcCost.toLocaleString("en-IN")}` : "—"} />
          <Row k="Full Panel Baseline" v={r.ihcCost != null && r.savings != null ? `₹${(r.ihcCost + r.savings).toLocaleString("en-IN")}` : "—"} />
          <Row k="Estimated Savings" v={r.savings != null ? `₹${r.savings.toLocaleString("en-IN")}` : "—"} />
        </Block>
      </section>

      <section className="mt-6">
        <SectionTitle>Morphological Findings</SectionTitle>
        <ul className="mt-2 list-disc space-y-1 pl-5 text-sm">
          {r.findings.map((f) => (
            <li key={f}>{f}</li>
          ))}
        </ul>
      </section>

      <section className="mt-6">
        <SectionTitle>Recommended Confirmatory Biomarkers</SectionTitle>
        <table className="mt-2 w-full text-sm">
          <thead className="text-muted-foreground border-b text-left text-xs uppercase">
            <tr>
              <th className="py-2 font-medium">Marker</th>



                    <th className="py-2 font-medium">Priority</th>
                    <th className="py-2 font-medium">Confidence</th>
                    <th className="py-2 font-medium">Recommendation</th>
                 </tr>
               </thead>
               <tbody>
                 {r.biomarkers.map((b) => (
                    <tr key={b.name} className="border-b last:border-0">
                      <td className="py-2 font-medium">{b.name}</td>
                      <td className="py-2">{b.priority}</td>
                      <td className="py-2">{b.confidence}%</td>
                      <td className="py-2">{b.recommendation}</td>
                    </tr>
                 ))}
               </tbody>
            </table>
         </section>

         <section className="mt-6">
            <SectionTitle>Recommendations</SectionTitle>
            <p className="mt-2 text-sm/6">{r.summary}</p>
         </section>

         <section className="mt-6">
            <SectionTitle>Doctor's Notes</SectionTitle>
            <Textarea
               value={notes}
               onChange={(e) => setNotes(e.target.value)}
               placeholder="Add pathologist observations before printing…"
               className="no-print mt-2 min-h-24 rounded-xl"
            />
            <p className="mt-2 hidden min-h-16 border-b border-dashed text-sm print:block">{notes}</p>
         </section>

         <footer className="mt-8 flex flex-wrap items-end justify-between gap-6 border-t pt-5">
            <div className="text-muted-foreground text-xs">
               <div className="flex h-20 w-20 items-center justify-center rounded-xl border border-dashed">
                 <QrCode className="h-8 w-8" strokeWidth={1.4} />
               </div>
               <p className="mt-1.5">QR verification placeholder</p>
            </div>
            <div className="text-right text-xs">
               <div className="ml-auto h-12 w-52 border-b border-dashed" />
               <p className="mt-1.5 font-medium">Digital signature placeholder</p>
               <p className="text-muted-foreground">{record.doctor}</p>
               <p className="text-muted-foreground">
                 Timestamp: {new Date(r.completedAt ?? "").toLocaleString("en-IN")}
               </p>
            </div>
         </footer>

         <p className="text-muted-foreground mt-5 border-t pt-4 text-center text-[11px]">
            This AI provides decision support only. Final diagnosis remains with the pathologist.
            Research &amp; Educational Use Only · OncoLens AI Prototype v1.0 · Made by Team SKY
         </p>
       </Card>
     </>
  );
}

function SectionTitle({ children }: { children: React.ReactNode }) {
  return (
     <h2 className="text-primary text-xs font-semibold tracking-wider uppercase">{children}</h2>
  );
}

function Block({ title, children }: { title: string; children: React.ReactNode }) {
  return (
     <div>
       <SectionTitle>{title}</SectionTitle>
       <dl className="mt-2 space-y-1.5 text-sm">{children}</dl>
     </div>
  );
}

function Row({ k, v }: { k: string; v: string }) {
  return (



     <div className="flex justify-between gap-4 border-b border-dashed pb-1 last:border-0">
       <dt className="text-muted-foreground">{k}</dt>
       <dd className="max-w-[62%] text-right font-medium">{v}</dd>
     </div>
  );
}




