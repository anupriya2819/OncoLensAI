import { createFileRoute, Link, useParams } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { PageHeader } from "@/components/oncolens/PageHeader";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useStore } from "@/lib/oncolens/store";

export const Route = createFileRoute("/app/patients/$patientId")({
  head: () => ({
    meta: [
       { title: "Patient Profile — OncoLens AI" },
       {
          name: "description",
          content: "Patient profile with previous pathology cases, reports, slide images and current status.",
       },
       { property: "og:title", content: "Patient Profile — OncoLens AI" },
       { property: "og:description", content: "Full pathology history for a registered patient." },
    ],
  }),
  component: PatientDetail,
});

function PatientDetail() {
  const { patientId } = useParams({ from: "/app/patients/$patientId" });
  const { patients, cases, updatePatient, log } = useStore();
  const patient = patients.find((p) => p.id === patientId);
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(patient);

  if (!patient) {
    return (
       <Card className="glass rounded-2xl p-12 text-center">
          <p className="font-medium">Patient not found</p>
          <Button asChild className="mt-4 rounded-xl">
            <Link to="/app/patients">Back to patients</Link>
          </Button>
       </Card>
    );
  }

  const pc = cases.filter((c) => c.patientId === patient.id);

  return (
    <>
       <PageHeader
          title={patient.name}
          subtitle={`${patient.id} · ${patient.hospitalId || "No hospital ID"} · ${patient.doctor}`}
          action={
            <div className="flex gap-2">
              <Button
                variant="outline"
                className="rounded-xl"
                onClick={() => {
                   setDraft(patient);
                   setEditing((v) => !v);
                }}
              >
                {editing ? "Close editor" : "Edit Patient"}
              </Button>
              <Button asChild className="rounded-xl">
                <Link to="/app/analysis" search={{ patientId: patient.id }}>
                   Create New Case
                </Link>
              </Button>
            </div>
          }
       />

       <div className="grid gap-5 lg:grid-cols-[1fr_1.6fr]">
          <Card className="glass h-fit rounded-2xl p-5">
            <h2 className="text-lg font-semibold">Patient Profile</h2>
            {editing && draft ? (



              <div className="mt-4 space-y-3">
                <Label>Name</Label>
                <Input
                   className="rounded-xl"
                   value={draft.name}
                   onChange={(e) => setDraft({ ...draft, name: e.target.value })}
                />
                <Label>Phone</Label>
                <Input
                   className="rounded-xl"
                   value={draft.phone}
                   onChange={(e) => setDraft({ ...draft, phone: e.target.value })}
                />
                <Label>Clinical Notes</Label>
                <Textarea
                   className="min-h-24 rounded-xl"
                   value={draft.notes}
                   onChange={(e) => setDraft({ ...draft, notes: e.target.value })}
                />
                <Button
                   className="rounded-xl"
                   onClick={() => {
                      updatePatient(draft);
                      log(`Patient updated — ${draft.name}`);
                      toast.success("Patient record updated.");
                      setEditing(false);
                   }}
                >
                   Save changes
                </Button>
              </div>
           ) : (
              <dl className="mt-4 space-y-3 text-sm">
                {[
                   ["Age", patient.age || "—"],
                   ["Gender", patient.gender],
                   ["Date of Birth", patient.dob || "—"],
                   ["Phone", patient.phone || "—"],
                   ["Email", patient.email || "—"],
                   ["Address", patient.address || "—"],
                   ["Clinical Notes", patient.notes || "—"],
                   ["Current Status", pc.some((c) => c.status === "Pending") ? "Analysis pending" : pc.length ? "Reports available" : "No cases"],
                ].map(([k, v]) => (
                   <div key={k} className="flex justify-between gap-6 border-b border-dashed pb-2 last:border-0">
                      <dt className="text-muted-foreground">{k}</dt>
                      <dd className="max-w-[60%] text-right font-medium">{v}</dd>
                   </div>
                ))}
              </dl>
           )}
         </Card>

         <div className="space-y-4">
           <Card className="glass rounded-2xl p-5">
              <h2 className="text-lg font-semibold">Previous Cases &amp; Reports</h2>
              {pc.length === 0 ? (
                <p className="text-muted-foreground mt-3 text-sm">No cases recorded yet.</p>
              ) : (
                <div className="mt-4 space-y-3">
                   {pc.map((c) => (
                      <div
                        key={c.id}
                        className="border-border/70 hover:bg-secondary/50 flex flex-wrap items-center gap-4 rounded-2xl border p-3 transition-colors"
                      >
                        <img
                           src={c.imageDataUrl}
                           alt={`Slide ${c.sampleId}`}
                           className="h-16 w-16 rounded-xl object-cover"
                        />
                        <div className="min-w-40 flex-1">
                           <p className="font-medium">{c.sampleId}</p>
                           <p className="text-muted-foreground text-xs">
                             {new Date(c.createdAt).toLocaleString("en-IN")} · {c.priority}
                           </p>
                           <p className="mt-1 text-sm">{c.result?.diagnosis ?? "Awaiting analysis"}</p>



                        </div>
                        <Badge variant="outline" className="rounded-full">
                           {c.result ? `${c.result.confidence}% confidence` : c.status}
                        </Badge>
                        {c.result && (
                           <Button asChild size="sm" variant="outline" className="rounded-xl">
                             <Link to="/app/reports/$caseId" params={{ caseId: c.id }}>
                               Report
                             </Link>
                           </Button>
                        )}
                      </div>
                   ))}
                 </div>
              )}
           </Card>

           <Card className="glass rounded-2xl p-5">
              <h2 className="text-lg font-semibold">Previous Images</h2>
              <div className="mt-4 grid grid-cols-3 gap-3 sm:grid-cols-5">
                 {pc.length === 0 && <p className="text-muted-foreground text-sm">No slides uploaded.</p>}
                 {pc.map((c) => (
                   <img
                      key={c.id}
                      src={c.imageDataUrl}
                      alt={`Uploaded slide ${c.sampleId}`}
                      className="lift aspect-square w-full rounded-xl object-cover"
                   />
                 ))}
              </div>
           </Card>
         </div>
       </div>
     </>
  );
}




