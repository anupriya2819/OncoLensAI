import { createFileRoute, Link } from "@tanstack/react-router";
import {
    Users,
    FlaskConical,
    Clock,
    FileCheck2,
    Gauge,
    IndianRupee,
    Timer,
    AlertTriangle,
    Plus,
    Sparkles,
    Search,
} from "lucide-react";
import { useMemo, useState } from "react";
import { PageHeader } from "@/components/oncolens/PageHeader";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useStore } from "@/lib/oncolens/store";

export const Route = createFileRoute("/app/dashboard")({
    head: () => ({
       meta: [
          { title: "Dashboard — OncoLens AI" },
          {
             name: "description",
             content:
               "Live overview of patients, pathology cases, pending AI analyses, confidence and estimated IHC cost savings.",
          },
          { property: "og:title", content: "Dashboard — OncoLens AI" },
          {
             property: "og:description",
             content: "Live overview of pathology cases, AI confidence and IHC cost savings.",
          },
       ],
    }),
    component: Dashboard,
});

function Dashboard() {
    const { patients, cases, activity, user } = useStore();
    const [q, setQ] = useState("");
    const [filter, setFilter] = useState<"All" | "Pending" | "Completed">("All");

    const done = cases.filter((c) => c.status === "Completed");
    const avgConfidence = done.length
       ? Math.round(done.reduce((a, c) => a + (c.result?.confidence ?? 0), 0) / done.length)
       : 0;
    const savings = done.reduce((a, c) => a + (c.result?.savings ?? 0), 0);
    const avgTime = done.length
       ? (done.reduce((a, c) => a + (c.result?.processingSeconds ?? 0), 0) / done.length).toFixed(1)
       : "0.0";
    const highPriority = cases.filter((c) => c.priority !== "Routine").length;

    const stats = [
       { label: "Total Patients", value: patients.length, icon: Users },
       { label: "Total Cases", value: cases.length, icon: FlaskConical },
       { label: "Pending Analysis", value: cases.length - done.length, icon: Clock },
       { label: "Completed Reports", value: done.length, icon: FileCheck2 },
       { label: "Average Confidence", value: `${avgConfidence}%`, icon: Gauge },
       { label: "Potential IHC Saved", value: `₹${savings.toLocaleString("en-IN")}`, icon: IndianRupee },
       { label: "Avg Processing Time", value: `${avgTime}s`, icon: Timer },
       { label: "High Priority Cases", value: highPriority, icon: AlertTriangle },
    ];

    const rows = useMemo(() => {
       const term = q.trim().toLowerCase();
       return patients
          .filter((p) => {
             const pc = cases.filter((c) => c.patientId === p.id);
             const matches =
               !term ||
               p.name.toLowerCase().includes(term) ||
               p.id.toLowerCase().includes(term) ||
               p.hospitalId.toLowerCase().includes(term);



        if (!matches) return false;
        if (filter === "All") return true;
        if (filter === "Pending") return pc.some((c) => c.status === "Pending") || pc.length === 0;
        return pc.some((c) => c.status === "Completed");
      })
      .slice(0, 8);
  }, [patients, cases, q, filter]);

  return (
    <>
       <PageHeader
          title={`Welcome back, ${user?.name?.split(" ").slice(-1)[0] ?? "Doctor"}`}
          subtitle="Snapshot of your pathology workload, AI throughput and cost impact across the department."
          action={
            <div className="flex gap-2">
              <Button asChild variant="outline" className="rounded-xl">
                <Link to="/app/patients/new">
                   <Plus className="mr-1 h-4 w-4" /> New Patient
                </Link>
              </Button>
              <Button asChild className="rounded-xl">
                <Link to="/app/analysis" search={{ patientId: undefined }}>
                   <Sparkles className="mr-1 h-4 w-4" /> New Analysis
                </Link>
              </Button>
            </div>
          }
       />

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {stats.map((s) => (
          <Card key={s.label} className="glass lift rounded-2xl p-5">
             <div className="flex items-start justify-between">
               <p className="text-muted-foreground text-sm font-medium">{s.label}</p>
               <div className="bg-accent text-accent-foreground flex h-9 w-9 items-center justify-center rounded-xl">
                 <s.icon className="h-[18px] w-[18px]" strokeWidth={1.7} />
               </div>
             </div>
             <p className="font-display mt-3 text-2xl font-semibold">{s.value}</p>
          </Card>
        ))}
      </div>

       <div className="mt-6 grid gap-5 lg:grid-cols-[1.6fr_1fr]">
         <Card className="glass rounded-2xl p-5">
           <div className="flex flex-wrap items-center justify-between gap-3">
             <h2 className="text-lg font-semibold">Recent Patients</h2>
             <div className="flex items-center gap-2">
               <div className="relative">
                  <Search className="text-muted-foreground pointer-events-none absolute top-1/2 left-3 h-4 w-4 -translate-y-1/2" />
                  <input
                     value={q}
                     onChange={(e) => setQ(e.target.value)}
                     placeholder="Search"
                     className="border-border bg-card/70 focus:ring-ring/40 rounded-xl border py-2 pr-3 pl-9 text-sm outline-none focus:ring-2"
                  />
               </div>
               {(["All", "Pending", "Completed"] as const).map((f) => (
                  <button
                     key={f}
                     onClick={() => setFilter(f)}
                     className={`rounded-xl px-3 py-2 text-xs font-medium transition-colors ${
                       filter === f
                         ? "bg-primary text-primary-foreground"
                         : "bg-secondary text-muted-foreground hover:text-foreground"
                     }`}
                  >
                     {f}
                  </button>
               ))}
             </div>
           </div>

           <div className="mt-4 overflow-x-auto">
             {rows.length === 0 ? (



                 <EmptyState />
              ) : (
                 <table className="w-full text-sm">
                   <thead className="text-muted-foreground text-left text-xs uppercase">
                      <tr>
                        <th className="py-2 font-medium">Patient</th>
                        <th className="py-2 font-medium">Hospital ID</th>
                        <th className="py-2 font-medium">Cases</th>
                        <th className="py-2 font-medium">Status</th>
                        <th className="py-2" />
                      </tr>
                   </thead>
                   <tbody>
                      {rows.map((p) => {
                        const pc = cases.filter((c) => c.patientId === p.id);
                        const pending = pc.some((c) => c.status === "Pending");
                        return (
                           <tr key={p.id} className="border-border/70 hover:bg-secondary/60 border-t transition-colors">
                             <td className="py-3">
                               <p className="font-medium">{p.name}</p>
                               <p className="text-muted-foreground text-xs">{p.id}</p>
                             </td>
                             <td className="text-muted-foreground py-3">{p.hospitalId || "—"}</td>
                             <td className="py-3">{pc.length}</td>
                             <td className="py-3">
                               <Badge variant="outline" className="rounded-full">
                                 {pc.length === 0 ? "No cases" : pending ? "Pending" : "Completed"}
                               </Badge>
                             </td>
                             <td className="py-3 text-right">
                               <Button asChild size="sm" variant="ghost" className="rounded-lg">
                                 <Link to="/app/patients/$patientId" params={{ patientId: p.id }}>
                                   View
                                 </Link>
                               </Button>
                             </td>
                           </tr>
                        );
                      })}
                   </tbody>
                 </table>
              )}
           </div>
         </Card>

         <Card className="glass rounded-2xl p-5">
           <h2 className="text-lg font-semibold">Recent Activity</h2>
           <div className="mt-4 space-y-4">
              {activity.length === 0 && (
                 <p className="text-muted-foreground text-sm">
                   No activity yet. Register a patient and run your first analysis.
                 </p>
              )}
              {activity.slice(0, 8).map((a) => (
                 <div key={a.id} className="flex gap-3">
                   <div className="bg-teal mt-1.5 h-2 w-2 shrink-0 rounded-full" />
                   <div>
                      <p className="text-sm">{a.text}</p>
                      <p className="text-muted-foreground text-xs">
                        {new Date(a.at).toLocaleString("en-IN")}
                      </p>
                   </div>
                 </div>
              ))}
           </div>
         </Card>
       </div>
     </>
  );
}

function EmptyState() {
  return (
     <div className="border-border/70 rounded-2xl border border-dashed px-6 py-12 text-center">
       <p className="text-sm font-medium">No patients yet</p>
       <p className="text-muted-foreground mt-1 text-sm">
         Register your first patient to start building case history.



       </p>
       <Button asChild className="mt-4 rounded-xl">
         <Link to="/app/patients/new">Register patient</Link>
       </Button>
     </div>
  );
}




