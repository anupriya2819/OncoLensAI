import { createFileRoute } from "@tanstack/react-router";
import { toast } from "sonner";
import { PageHeader } from "@/components/oncolens/PageHeader";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { useStore } from "@/lib/oncolens/store";

export const Route = createFileRoute("/app/settings")({
   head: () => ({
     meta: [
        { title: "Settings — OncoLens AI" },
        {
           name: "description",
           content: "Profile, notifications, security, session timeout, API integration and backend connection settings.",
        },
        { property: "og:title", content: "Settings — OncoLens AI" },
        { property: "og:description", content: "Workspace, security and backend configuration." },
     ],
   }),
   component: SettingsPage,
});

function SettingsPage() {
   const { user, backendConnected } = useStore();

   return (
     <>
        <PageHeader title="Settings" subtitle="Workspace preferences, security posture and backend configuration." />
        <div className="grid gap-5 lg:grid-cols-2">
           <Card className="glass rounded-2xl p-5">
             <h2 className="text-lg font-semibold">Profile</h2>
             <div className="mt-4 space-y-3">
               <Label>Name</Label>
               <Input className="rounded-xl" defaultValue={user?.name ?? ""} />
               <Label>Email</Label>
               <Input className="rounded-xl" defaultValue={user?.email ?? ""} />
               <Label>Role</Label>
               <Input className="rounded-xl" value={user?.role ?? ""} readOnly />
               <Button className="rounded-xl" onClick={() => toast.success("Profile updated.")}>
                  Save profile
               </Button>
             </div>
           </Card>

           <Card className="glass rounded-2xl p-5">
             <h2 className="text-lg font-semibold">Notifications</h2>
             <div className="mt-4 space-y-3">
               {[
                  "Analysis complete",
                  "Report generated",
                  "Image quality poor",
                  "Patient added",
                  "Case saved",
                  "Report downloaded",
               ].map((n) => (
                  <div key={n} className="flex items-center justify-between rounded-xl border p-3 text-sm">
                    {n}
                    <Switch defaultChecked />
                  </div>
               ))}
             </div>
           </Card>

           <Card className="glass rounded-2xl p-5">
             <h2 className="text-lg font-semibold">Security</h2>
             <div className="mt-4 space-y-3 text-sm">
               {[
                  ["Role-based access control", "Enabled"],
                  ["Patient privacy scoping", "Enabled"],
                  ["Encrypted storage", "AES-256 (indicator)"],
                  ["Audit trail", "Recording"],
                  ["Session timeout", "20 minutes"],



              ].map(([k, v]) => (
                <div key={k} className="flex items-center justify-between border-b border-dashed pb-2 last:border-0">
                  <span className="text-muted-foreground">{k}</span>
                  <Badge variant="outline" className="rounded-full">
                    {v}
                  </Badge>
                </div>
              ))}
           </div>
         </Card>

         <Card className="glass rounded-2xl p-5">
           <h2 className="text-lg font-semibold">Backend &amp; API Integration</h2>
           <p className="text-muted-foreground mt-2 text-sm">
              Every form and page in OncoLens AI is already shaped for CRUD persistence. Connecting a
              backend requires no frontend redesign.
           </p>
           <div className="mt-4 flex items-center gap-2">
              <span className={`h-2 w-2 rounded-full ${backendConnected ? "bg-success" : "bg-warn"}`} />
              <span className="text-sm font-medium">
                {backendConnected ? "Backend Connected" : "Backend not connected"}
              </span>
           </div>
           <div className="mt-4 space-y-3">
              <Label>AI model endpoint</Label>
              <Input className="rounded-xl" placeholder="https://api.oncolens.ai/v1/infer" />
              <p className="text-muted-foreground text-xs">
                The frontend reads the API base URL from <code>VITE_API_BASE_URL</code>. Endpoint paths are maintained in <code>src/api/endpoints.ts</code>.
              </p>
           </div>
         </Card>
       </div>
     </>
  );
}




