import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import {
   UploadCloud,
   CheckCircle2,
   AlertTriangle,
   Loader2,
   ImageIcon,
   ShieldAlert,
   Sparkles,
   FileText,
   Bot,
} from "lucide-react";
import { toast } from "sonner";
import { PageHeader } from "@/components/oncolens/PageHeader";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Textarea } from "@/components/ui/textarea";
import {
   Select,
   SelectContent,
   SelectItem,
   SelectTrigger,
   SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { HeatmapImage } from "@/components/oncolens/HeatmapImage";
import { useStore } from "@/lib/oncolens/store";
import { assessImageQuality, runAnalysis } from "@/api/predictionApi";
import type { AnalysisResult, CaseRecord, QualityMetric } from "@/lib/oncolens/types";
import { DOCTORS } from "./app.patients.new";

export const Route = createFileRoute("/app/analysis")({
   validateSearch: (search: Record<string, unknown>) => ({
     patientId: typeof search['patientId'] === "string" ? search['patientId'] : undefined,
   }),
   head: () => ({
     meta: [
        { title: "New Analysis — OncoLens AI" },
        {
           name: "description",
           content:
             "Upload an H&E histopathology slide and send it to the connected AI backend for analysis.",
        },
        { property: "og:title", content: "New Analysis — OncoLens AI" },
        {
           property: "og:description",
           content: "Upload a slide and run AI-assisted pathology decision support.",
        },
     ],
   }),
   component: AnalysisPage,
});

type Step = "case" | "quality" | "preprocess" | "processing" | "results";

function AnalysisPage() {
   const { patientId } = Route.useSearch();
   const { patients, addCase, log } = useStore();
   const navigate = useNavigate();
   const fileRef = useRef<HTMLInputElement>(null);

   const [step, setStep] = useState<Step>("case");
   const [dragging, setDragging] = useState(false);
   const [image, setImage] = useState<{ file: File; url: string; name: string; pixels: number } | null>(null);
   const [quality, setQuality] = useState<QualityMetric[]>([]);
  const [qualityPassed, setQualityPassed] = useState(false);



  const [caseId, setCaseId] = useState<string | null>(null);
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [showHeat, setShowHeat] = useState(true);
  const [showRoi, setShowRoi] = useState(true);

  const [form, setForm] = useState({
    sampleId: `S-${Math.floor(10000 + Math.random() * 89999)}`,
    patientId: patientId ?? "",
    clinicalHistory: "",
    priority: "Routine" as CaseRecord["priority"],
    doctor: DOCTORS[0]!,
  });

  useEffect(() => {
    if (patientId) setForm((f) => ({ ...f, patientId }));
  }, [patientId]);

  function handleFile(file: File) {
    if (!/image\/(jpeg|jpg|png|tiff)/i.test(file.type) && !/\.(tif|tiff)$/i.test(file.name)) {
       toast.error("Supported formats: JPG, PNG, TIFF.");
       return;
    }
    const reader = new FileReader();
    reader.onload = () => {
       const url = String(reader.result);
       const img = new Image();
       img.onload = () => {
          setImage({ file, url, name: file.name, pixels: img.width * img.height });
          toast.success("Slide uploaded. This exact image is used across the workflow.");
       };
       img.onerror = () => setImage({ file, url, name: file.name, pixels: 0 });
       img.src = url;
    };
    reader.readAsDataURL(file);
  }

  async function runQuality() {
    if (!image) {
      toast.error("Upload an H&E slide image first.");
      return;
    }
    if (!form.patientId) {
      toast.error("Select the patient this sample belongs to.");
      return;
    }

    try {
      const response = await assessImageQuality(image.file);
      if (!Array.isArray(response.metrics)) {
        throw new Error("The backend returned an invalid quality-assessment response.");
      }
      setQuality(response.metrics);
      setQualityPassed(Boolean(response.passed));
      setStep("quality");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Image quality assessment failed.");
    }
  }

  async function startAnalysis() {
    if (!image) return;

    setStep("processing");
    try {
      const response = await runAnalysis({
        image: image.file,
        sampleId: form.sampleId,
        patientId: form.patientId,
        clinicalHistory: form.clinicalHistory,
        priority: form.priority,
        doctor: form.doctor,
      });

      if (!response?.diagnosis || typeof response.confidence !== "number") {
        throw new Error("The backend returned an incomplete analysis response.");
      }

      const patient = patients.find((p) => p.id === form.patientId);
      const record: CaseRecord = {
        id: `case-${Date.now()}`,
        sampleId: form.sampleId,
        patientId: form.patientId,
        patientName: patient?.name ?? "Unknown patient",
        clinicalHistory: form.clinicalHistory,
        priority: form.priority,
        doctor: form.doctor,
        imageDataUrl: image.url,
        imageName: image.name,
        createdAt: new Date().toISOString(),
        status: "Completed",
        quality,
        qualityPassed: true,
        result: response,
      };

      addCase(record);
      setCaseId(record.id);
      setResult(response);
      log(`Analysis complete — ${form.sampleId}`);
      toast.success("Analysis complete.");
      setStep("results");
    } catch (error) {
      setStep("quality");
      toast.error(error instanceof Error ? error.message : "Analysis failed. Please try again.");
    }
  }

   return (
     <>
        <PageHeader
           title="New Analysis"
           subtitle="Register the sample, upload the H&E slide and run the AI-assisted pipeline. AI outputs are supplied by the connected backend model."
           action={
             <Badge variant="outline" className="rounded-full py-1.5">
               Step {["case", "quality", "preprocess", "processing", "results"].indexOf(step) + 1} of 5
             </Badge>
           }
        />

        <Stepper step={step} />

        {step === "case" && (
           <div className="grid gap-5 lg:grid-cols-[1fr_1.15fr]">
             <Card className="glass h-fit rounded-2xl p-6">
               <h2 className="text-lg font-semibold">Case Details</h2>
               <div className="mt-4 space-y-4">
                 <div className="space-y-2">
                    <Label>Sample ID</Label>
                    <Input
                       className="rounded-xl"
                       value={form.sampleId}
                       onChange={(e) => setForm({ ...form, sampleId: e.target.value })}
                    />
                 </div>
                 <div className="space-y-2">
                    <Label>Patient</Label>
                    <Select
                       value={form.patientId}
                       onValueChange={(v) => setForm({ ...form, patientId: v })}
                    >
                       <SelectTrigger className="rounded-xl">
                         <SelectValue placeholder="Select registered patient" />
                       </SelectTrigger>
                       <SelectContent>
                         {patients.map((p) => (
                            <SelectItem key={p.id} value={p.id}>
                              {p.name} · {p.id}
                            </SelectItem>
                         ))}
                       </SelectContent>
                    </Select>
                    {patients.length === 0 && (
                       <p className="text-muted-foreground text-xs">
                         No patients yet —{" "}
                         <Link to="/app/patients/new" className="text-primary underline">
                            register one first
                         </Link>
                         .
                       </p>
                    )}
                 </div>
                 <div className="space-y-2">
                    <Label>Clinical History</Label>
                    <Textarea
                       className="min-h-24 rounded-xl"
                       placeholder="Lump in upper outer quadrant, BIRADS 4C on mammography…"
                       value={form.clinicalHistory}
                       onChange={(e) => setForm({ ...form, clinicalHistory: e.target.value })}
                    />
                 </div>
                 <div className="grid grid-cols-2 gap-4">



                <div className="space-y-2">
                   <Label>Priority</Label>
                   <Select
                     value={form.priority}
                     onValueChange={(v) => setForm({ ...form, priority: v as CaseRecord["priority"] })}
                   >
                     <SelectTrigger className="rounded-xl">
                       <SelectValue />
                     </SelectTrigger>
                     <SelectContent>
                       {["Routine", "Urgent", "Critical"].map((p) => (
                         <SelectItem key={p} value={p}>
                           {p}
                         </SelectItem>
                       ))}
                     </SelectContent>
                   </Select>
                </div>
                <div className="space-y-2">
                   <Label>Doctor</Label>
                   <Select value={form.doctor} onValueChange={(v) => setForm({ ...form, doctor: v })}>
                     <SelectTrigger className="rounded-xl">
                       <SelectValue />
                     </SelectTrigger>
                     <SelectContent>
                       {DOCTORS.map((d) => (
                         <SelectItem key={d} value={d}>
                           {d}
                         </SelectItem>
                       ))}
                     </SelectContent>
                   </Select>
                </div>
              </div>

            </div>
          </Card>

           <Card className="glass rounded-2xl p-6">
             <h2 className="text-lg font-semibold">Upload H&amp;E Image</h2>
             <div
               onDragOver={(e) => {
                  e.preventDefault();
                  setDragging(true);
               }}
               onDragLeave={() => setDragging(false)}
               onDrop={(e) => {
                  e.preventDefault();
                  setDragging(false);
                  const f = e.dataTransfer.files?.[0];
                  if (f) handleFile(f);
               }}
               onClick={() => fileRef.current?.click()}
               className={`mt-4 flex cursor-pointer flex-col items-center justify-center rounded-2xl border-2 border-d
 ashed px-6 py-14 text-center transition-all ${
                  dragging ? "border-primary bg-brand-soft scale-[1.01]" : "border-border hover:border-primary/60"
               }`}
             >
               <div className="brand-gradient text-primary-foreground flex h-14 w-14 items-center justify-center rounded-2xl">
                  <UploadCloud className="h-6 w-6" strokeWidth={1.7} />
               </div>
               <p className="mt-4 font-medium">Drag &amp; drop your slide here</p>
               <p className="text-muted-foreground mt-1 text-sm">or click to browse · JPG, PNG, TIFF</p>
               <input
                  ref={fileRef}
                  type="file"
                  accept=".jpg,.jpeg,.png,.tif,.tiff,image/*"
                  className="hidden"
                  onChange={(e) => {
                    const f = e.target.files?.[0];



                  if (f) handleFile(f);
                }}
              />
            </div>

            {image && (
               <div className="animate-rise mt-5">
                 <div className="flex items-center gap-2 text-sm">
                    <ImageIcon className="text-teal h-4 w-4" />
                    <span className="font-medium">{image.name}</span>
                    <span className="text-muted-foreground text-xs">
                      {Math.round(image.pixels / 1000).toLocaleString("en-IN")}k px
                    </span>
                 </div>
                 <img
                    src={image.url}
                    alt="Uploaded H&E slide preview"
                    className="mt-3 max-h-72 w-full rounded-2xl object-cover"
                 />
               </div>
            )}

            <Button className="mt-6 h-11 w-full rounded-xl" onClick={runQuality} disabled={!image}>
               Run Image Quality Assessment
            </Button>
          </Card>
        </div>
      )}

       {step === "quality" && image && (
         <Card className="glass rounded-2xl p-6">
           <div className="flex flex-wrap items-center justify-between gap-3">
              <h2 className="text-lg font-semibold">Image Quality Assessment</h2>
              <Badge
                className={`rounded-full ${qualityPassed ? "bg-success text-primary-foreground" : "bg-warn text-primary-foreground"}`}
              >
                {qualityPassed ? "Passed" : "Needs re-upload"}
              </Badge>
           </div>

           <div className="mt-5 grid gap-5 lg:grid-cols-[1fr_1fr]">
              <img src={image.url} alt="Slide under quality assessment" className="w-full rounded-2xl" />
              <div className="space-y-4">
                {quality.map((m) => (
                  <div key={m.label}>
                     <div className="flex items-center justify-between text-sm">
                       <span className="font-medium">{m.label}</span>
                       <span className={m.ok ? "text-success" : "text-warn"}>
                         {m.value}
                         {m.unit}
                       </span>
                     </div>
                     <Progress value={Math.min(100, m.value)} className="mt-2 h-2" />
                  </div>
                ))}
              </div>
           </div>

           {!qualityPassed && (
              <div className="border-warn/40 bg-warn/10 mt-6 flex gap-3 rounded-2xl border p-4">
                <AlertTriangle className="text-warn mt-0.5 h-5 w-5 shrink-0" />
                <div>
                  <p className="font-medium">Slide quality below diagnostic threshold</p>
                  <p className="text-muted-foreground mt-1 text-sm">
                     Analysis has been disabled to prevent unreliable predictions. Please rescan the slide
                     at higher magnification with proper focus and staining, then upload again.
                  </p>
                </div>
              </div>
           )}

           <div className="mt-6 flex flex-wrap gap-3">
              <Button
                className="rounded-xl"
                disabled={!qualityPassed}
                onClick={startAnalysis}



          >
            <Sparkles className="mr-1 h-4 w-4" /> Send to AI Backend
          </Button>
          <Button
            variant="outline"
            className="rounded-xl"
            onClick={() => {
               setImage(null);
               setQuality([]);
               setQualityPassed(false);
               setStep("case");
            }}
          >
            Upload another image
          </Button>
        </div>
      </Card>
    )}

    {step === "preprocess" && (
      <BackendStage
        title="Preparing analysis"
        message="The frontend is ready to send the slide to the connected backend."
      />
    )}

    {step === "processing" && (
      <BackendStage
        title="AI Processing"
        message="The backend is processing the uploaded slide. This screen updates when the API request completes."
      />
    )}

    {step === "results" && image && result && (
      <div className="animate-rise space-y-5">
        <div className="grid gap-5 lg:grid-cols-[1.2fr_1fr]">
          <Card className="glass rounded-2xl p-5">
            <div className="flex flex-wrap items-center justify-between gap-3">
               <h2 className="text-lg font-semibold">Explainable AI Overlay</h2>
               <div className="flex items-center gap-4 text-xs">
                 <label className="flex items-center gap-2">
                   <Switch checked={showHeat} onCheckedChange={setShowHeat} /> Grad-CAM heatmap
                 </label>
                 <label className="flex items-center gap-2">
                   <Switch checked={showRoi} onCheckedChange={setShowRoi} /> ROI
                 </label>
               </div>
            </div>
            <HeatmapImage
               className="mt-4"
               src={image.url}
               heatmapSrc={result.heatmapUrl}
               rois={result.rois}
               showHeatmap={showHeat}
               showRoi={showRoi}
            />
            <p className="text-muted-foreground mt-3 text-xs">
               Warmer regions indicate areas that contributed most to the model's prediction. ROI boxes
               mark the highest-scoring suspicious fields for pathologist review.
            </p>
          </Card>

          <div className="space-y-4">
            <Card className="glass rounded-2xl p-5">
              <p className="text-muted-foreground text-xs tracking-wide uppercase">AI Diagnosis</p>
              <h3 className="font-display mt-1.5 text-xl font-semibold">{result.diagnosis}</h3>
              <div className="mt-4 flex items-center gap-3">
                <Badge
                  className={`rounded-full ${
                    result.risk === "High"
                       ? "bg-destructive text-primary-foreground"
                       : result.risk === "Moderate"
                         ? "bg-warn text-primary-foreground"
                         : "bg-success text-primary-foreground"



                    }`}
                >
                  {result.risk} risk
                </Badge>
                <span className="text-muted-foreground text-sm">
{result.processingSeconds != null ? `Processed in ${result.processingSeconds}s` : "Processing time supplied by backend"}
                </span>
              </div>
              <div className="mt-5">
                <div className="flex justify-between text-sm">
                  <span className="font-medium">Confidence</span>
                  <span className="brand-text font-semibold">{result.confidence}%</span>
                </div>
                <Progress value={result.confidence} className="mt-2 h-2.5" />
              </div>
              <ul className="mt-5 space-y-2 text-sm">
                {result.findings.map((f) => (
                  <li key={f} className="flex gap-2">
                     <CheckCircle2 className="text-teal mt-0.5 h-4 w-4 shrink-0" />
                     {f}
                  </li>
                ))}
              </ul>
            </Card>

            <Card className="glass rounded-2xl p-5">
               <p className="text-muted-foreground text-xs tracking-wide uppercase">Cost impact</p>
               <div className="mt-3 flex items-end gap-6">
                 <div>
                   <p className="font-display text-2xl font-semibold">
                      ₹{(result.ihcCost ?? 0).toLocaleString("en-IN")}
                   </p>
                   <p className="text-muted-foreground text-xs">Prioritised IHC panel</p>
                 </div>
                 <div>
                   <p className="text-success font-display text-2xl font-semibold">
                      ₹{(result.savings ?? 0).toLocaleString("en-IN")}
                   </p>
                   <p className="text-muted-foreground text-xs">Estimated saving vs full panel</p>
                 </div>
               </div>
            </Card>
          </div>
        </div>

        <Card className="glass rounded-2xl p-5">
          <h2 className="text-lg font-semibold">Recommended Confirmatory Biomarkers</h2>
          <div className="mt-4 grid gap-4 md:grid-cols-2 xl:grid-cols-4">
            {result.biomarkers.map((b) => (
              <div key={b.name} className="lift bg-card/70 rounded-2xl border p-4">
                 <div className="flex items-center justify-between">
                   <p className="font-display text-lg font-semibold">{b.name}</p>
                   <Badge
                     variant={b.priority === "High" ? "default" : "outline"}
                     className="rounded-full"
                   >
                     {b.priority}
                   </Badge>
                 </div>
                 <Progress value={b.confidence} className="mt-3 h-1.5" />
                 <p className="text-muted-foreground mt-2 text-xs">{b.confidence}% confidence</p>
                 <p className="mt-3 text-sm font-medium">{b.recommendation}</p>
                 <p className="text-muted-foreground mt-2 text-xs/5">{b.rationale}</p>
              </div>
            ))}
          </div>
        </Card>

        <Card className="glass rounded-2xl p-5">
          <h2 className="text-lg font-semibold">AI Clinical Summary</h2>
          <p className="mt-3 text-sm/7">{result.summary}</p>
          <div className="border-primary/25 bg-brand-soft/60 mt-5 flex gap-3 rounded-2xl border p-4">
            <ShieldAlert className="text-primary mt-0.5 h-5 w-5 shrink-0" />
            <p className="text-sm font-medium">
              This AI provides decision support only. Final diagnosis remains with the pathologist.
            </p>
          </div>



               <div className="mt-5 flex flex-wrap gap-3">
                 {caseId && (
                    <Button asChild className="rounded-xl">
                      <Link to="/app/reports/$caseId" params={{ caseId }}>
                        <FileText className="mr-1 h-4 w-4" /> Open printable report
                      </Link>
                    </Button>
                 )}
                 <Button asChild variant="outline" className="rounded-xl">
                    <Link to="/app/assistant">
                      <Bot className="mr-1 h-4 w-4" /> Ask the AI Assistant
                    </Link>
                 </Button>
                 <Button
                    variant="ghost"
                    className="rounded-xl"
                    onClick={() => navigate({ to: "/app/history" })}
                 >
                    View case history
                 </Button>
               </div>
            </Card>
          </div>
       )}
     </>
  );
}

function Stepper({ step }: { step: Step }) {
  const items: { key: Step; label: string }[] = [
     { key: "case", label: "Case & Upload" },
     { key: "quality", label: "Quality Check" },
     { key: "preprocess", label: "Preprocessing" },
     { key: "processing", label: "AI Processing" },
     { key: "results", label: "Results" },
  ];
  const active = items.findIndex((i) => i.key === step);
  return (
     <div className="mb-6 flex flex-wrap gap-2">
       {items.map((i, idx) => (
          <div
            key={i.key}
            className={`flex items-center gap-2 rounded-full px-4 py-2 text-xs font-medium transition-colors ${
               idx < active
                 ? "bg-teal/15 text-teal"
                 : idx === active
                    ? "brand-gradient text-primary-foreground"
                    : "bg-secondary text-muted-foreground"
            }`}
          >
            <span className="opacity-70">{idx + 1}</span>
            {i.label}
          </div>
       ))}
     </div>
  );
}

function BackendStage({ title, message }: { title: string; message: string }) {
  return (
    <Card className="glass mx-auto max-w-2xl rounded-2xl p-8 text-center">
      <div className="brand-gradient text-primary-foreground mx-auto flex h-16 w-16 items-center justify-center rounded-3xl">
        <Loader2 className="h-7 w-7 animate-spin" strokeWidth={1.7} />
      </div>
      <h2 className="mt-5 text-xl font-semibold">{title}</h2>
      <p className="text-muted-foreground mx-auto mt-2 max-w-lg text-sm leading-6">{message}</p>
      <p className="text-muted-foreground mt-2 text-xs">Waiting for the backend response…</p>
      <div className="bg-brand-soft/70 mt-6 rounded-xl p-3 text-left text-xs">
        <span className="font-medium">No local processing is running.</span>{" "}
        Progress is determined by the connected API.
      </div>
    </Card>
  );
}
