import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { PageHeader } from "@/components/oncolens/PageHeader";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
   Select,
   SelectContent,
   SelectItem,
   SelectTrigger,
   SelectValue,
} from "@/components/ui/select";
import { useStore } from "@/lib/oncolens/store";

export const Route = createFileRoute("/app/patients/new")({
   head: () => ({
     meta: [
        { title: "Register New Patient — OncoLens AI" },
        {
           name: "description",
           content:
             "Register a patient with demographics, contact details, clinical notes and assigned pathologist.",
        },
        { property: "og:title", content: "Register New Patient — OncoLens AI" },
        { property: "og:description", content: "Create a patient record for pathology case tracking." },
     ],
   }),
   component: NewPatient,
});

export const DOCTORS = [
   "Dr. Kavya Mehra (Pathology)",
   "Dr. Arjun Iyer (Surgical Oncology)",
   "Dr. Neha Bansal (Medical Oncology)",
   "Dr. Rohit Sharma (Histopathology)",
];

function NewPatient() {
   const { addPatient, log } = useStore();
   const navigate = useNavigate();
   const [form, setForm] = useState({
     id: `PT-${Math.floor(1000 + Math.random() * 9000)}`,
     hospitalId: "",
     name: "",
     age: "",
     gender: "Female",
     dob: "",
     phone: "",
     email: "",
     address: "",
     notes: "",
     doctor: DOCTORS[0]!,
   });

   const set = (k: keyof typeof form) => (v: string) => setForm((f) => ({ ...f, [k]: v }));

   function save(e: React.FormEvent) {
     e.preventDefault();
     if (!form.name.trim() || !form.age.trim()) {
        toast.error("Patient name and age are required.");
        return;
     }
     addPatient({ ...form, createdAt: new Date().toISOString() });
     log(`Patient added — ${form.name} (${form.id})`);
     toast.success("Patient saved to case registry.");
     navigate({ to: "/app/patients" });
   }

   return (
     <>
        <PageHeader
           title="New Patient"
           subtitle="Patient registration. Records are stored locally in this prototype and are ready to sync when a backend is connected."
      />
      <Card className="glass mx-auto max-w-4xl rounded-2xl p-6 lg:p-8">
         <form onSubmit={save} className="grid gap-5 md:grid-cols-2">
           <Field label="Patient ID">
             <Input className="rounded-xl" value={form.id} onChange={(e) => set("id")(e.target.value)} />
           </Field>
           <Field label="Hospital Patient ID">
             <Input
                className="rounded-xl"
                placeholder="APEX/2026/00123"
                value={form.hospitalId}
                onChange={(e) => set("hospitalId")(e.target.value)}
             />
           </Field>
           <Field label="Full Name">
             <Input className="rounded-xl" value={form.name} onChange={(e) => set("name")(e.target.value)} />
           </Field>
           <div className="grid grid-cols-2 gap-4">
             <Field label="Age">
                <Input
                   className="rounded-xl"
                   inputMode="numeric"
                   value={form.age}
                   onChange={(e) => set("age")(e.target.value)}
                />
             </Field>
             <Field label="Gender">
                <Select value={form.gender} onValueChange={set("gender")}>
                   <SelectTrigger className="rounded-xl">
                     <SelectValue />
                   </SelectTrigger>
                   <SelectContent>
                     {["Female", "Male", "Other"].map((g) => (
                       <SelectItem key={g} value={g}>
                         {g}
                       </SelectItem>
                     ))}
                   </SelectContent>
                </Select>
             </Field>
           </div>
           <Field label="Date of Birth">
             <Input
                type="date"
                className="rounded-xl"
                value={form.dob}
                onChange={(e) => set("dob")(e.target.value)}
             />
           </Field>
           <Field label="Phone">
             <Input
                className="rounded-xl"
                placeholder="+91 98xxxxxxx"
                value={form.phone}
                onChange={(e) => set("phone")(e.target.value)}
             />
           </Field>
           <Field label="Email">
             <Input
                type="email"
                className="rounded-xl"
                value={form.email}
                onChange={(e) => set("email")(e.target.value)}
             />
           </Field>
           <Field label="Assign Doctor">
             <Select value={form.doctor} onValueChange={set("doctor")}>
                <SelectTrigger className="rounded-xl">
                   <SelectValue />
                </SelectTrigger>
                <SelectContent>
                   {DOCTORS.map((d) => (
                     <SelectItem key={d} value={d}>
                       {d}
                     </SelectItem>
                   ))}



                </SelectContent>
              </Select>
            </Field>
            <div className="md:col-span-2">
              <Field label="Address">
                <Textarea
                   className="min-h-20 rounded-xl"
                   value={form.address}
                   onChange={(e) => set("address")(e.target.value)}
                />
              </Field>
            </div>
            <div className="md:col-span-2">
              <Field label="Clinical Notes">
                <Textarea
                   className="min-h-28 rounded-xl"
                   placeholder="Presenting complaint, prior biopsies, family history, imaging correlation…"
                   value={form.notes}
                   onChange={(e) => set("notes")(e.target.value)}
                />
              </Field>
            </div>

            <div className="flex gap-3 md:col-span-2">
              <Button type="submit" className="rounded-xl">
                Save Patient
              </Button>
              <Button
                type="button"
                variant="outline"
                className="rounded-xl"
                onClick={() => navigate({ to: "/app/patients" })}
              >
                Cancel
              </Button>
            </div>
         </form>
       </Card>
     </>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
     <div className="space-y-2">
       <Label>{label}</Label>
       {children}
     </div>
  );
}




