import { createFileRoute, Link } from "@tanstack/react-router";
import { Search, UserPlus } from "lucide-react";
import { useState } from "react";
import { PageHeader } from "@/components/oncolens/PageHeader";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useStore } from "@/lib/oncolens/store";

export const Route = createFileRoute("/app/patients/")({
   head: () => ({
      meta: [
         { title: "Existing Patients — OncoLens AI" },
         {
            name: "description",
            content: "Search the patient registry by name, patient ID or hospital ID and open full case history.",
         },
         { property: "og:title", content: "Existing Patients — OncoLens AI" },
         { property: "og:description", content: "Search and manage registered pathology patients." },
      ],
   }),
   component: PatientsPage,
});

function PatientsPage() {
   const { patients, cases } = useStore();
   const [q, setQ] = useState("");
   const term = q.trim().toLowerCase();
   const list = patients.filter(
      (p) =>
         !term ||
         p.name.toLowerCase().includes(term) ||
         p.id.toLowerCase().includes(term) ||
         p.hospitalId.toLowerCase().includes(term),
   );

   return (
      <>
         <PageHeader
            title="Existing Patients"
            subtitle="Search by patient name, patient ID or hospital ID to review profiles, prior cases, reports and slide images."
            action={
               <Button asChild className="rounded-xl">
                 <Link to="/app/patients/new">
                    <UserPlus className="mr-1 h-4 w-4" /> New Patient
                 </Link>
               </Button>
            }
         />

         <div className="relative mb-5 max-w-lg">
            <Search className="text-muted-foreground pointer-events-none absolute top-1/2 left-3.5 h-4 w-4 -translate-y-1/2" />
            <input
               value={q}
               onChange={(e) => setQ(e.target.value)}
               placeholder="Search patient name, ID or hospital ID"
               className="glass focus:ring-ring/40 w-full rounded-2xl py-3 pr-4 pl-10 text-sm outline-none focus:ring-2"
            />
         </div>

         {list.length === 0 ? (
            <Card className="glass rounded-2xl p-12 text-center">
               <p className="font-medium">No matching patients</p>
               <p className="text-muted-foreground mt-1 text-sm">
                 Register a patient to begin tracking pathology cases.
               </p>
            </Card>
         ) : (
            <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
               {list.map((p) => {
                 const pc = cases.filter((c) => c.patientId === p.id);
                 const latest = pc[0];
                 return (
                    <Card key={p.id} className="glass lift rounded-2xl p-5">
                      <div className="flex items-start justify-between gap-3">



                      <div>
                        <p className="font-display text-lg font-semibold">{p.name}</p>
                        <p className="text-muted-foreground text-xs">
                          {p.id} · {p.hospitalId || "No hospital ID"}
                        </p>
                      </div>
                      <Badge variant="outline" className="rounded-full">
                        {latest ? latest.status : "No cases"}
                      </Badge>
                   </div>
                   <dl className="text-muted-foreground mt-4 grid grid-cols-2 gap-y-2 text-xs">
                      <div>
                        <dt>Age / Gender</dt>
                        <dd className="text-foreground font-medium">
                          {p.age || "—"} · {p.gender}
                        </dd>
                      </div>
                      <div>
                        <dt>Cases</dt>
                        <dd className="text-foreground font-medium">{pc.length}</dd>
                      </div>
                      <div className="col-span-2">
                        <dt>Assigned doctor</dt>
                        <dd className="text-foreground font-medium">{p.doctor}</dd>
                      </div>
                   </dl>
                   {latest && (
                      <div className="mt-4 flex gap-2 overflow-hidden">
                        {pc.slice(0, 4).map((c) => (
                          <img
                             key={c.id}
                             src={c.imageDataUrl}
                             alt={`Slide for ${c.sampleId}`}
                             className="h-12 w-12 rounded-lg object-cover"
                          />
                        ))}
                      </div>
                   )}
                   <div className="mt-5 flex flex-wrap gap-2">
                      <Button asChild size="sm" className="rounded-xl">
                        <Link to="/app/analysis" search={{ patientId: p.id }}>
                          New Case
                        </Link>
                      </Button>
                      <Button asChild size="sm" variant="outline" className="rounded-xl">
                        <Link to="/app/patients/$patientId" params={{ patientId: p.id }}>
                          View History
                        </Link>
                      </Button>
                   </div>
                 </Card>
              );
            })}
          </div>
       )}
     </>
  );
}




