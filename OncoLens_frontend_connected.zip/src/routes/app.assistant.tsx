import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Bot, Send, User } from "lucide-react";
import { PageHeader } from "@/components/oncolens/PageHeader";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useStore } from "@/lib/oncolens/store";
import { askAssistant } from "@/api/assistantApi";

export const Route = createFileRoute("/app/assistant")({
   head: () => ({
     meta: [
        { title: "AI Assistant — OncoLens AI" },
        {
           name: "description",
           content: "Explainable AI assistant answering why specific biomarkers, heatmap regions and next diagnostic steps were recommended.",
        },
        { property: "og:title", content: "AI Assistant — OncoLens AI" },
        { property: "og:description", content: "Ask questions about the latest pathology report." },
     ],
   }),
   component: AssistantPage,
});

const PROMPTS = [
   "Why HER2?",
   "Why Ki-67?",
   "Explain this heatmap.",
   "Why was this classified as suspicious?",
   "What are the next diagnostic steps?",
   "Limitations of the prediction?",
];

function AssistantPage() {
  const { cases } = useStore();
  const latest = cases.find((c) => c.result);
  const [messages, setMessages] = useState<{ role: "user" | "ai"; text: string }[]>([
    {
      role: "ai",
      text: latest?.result?.reportId
        ? `Report ${latest.result.reportId} is selected. Ask a question and the connected assistant API will respond using the report context.`
        : "No completed analysis is available in this frontend session. Run an analysis first, then connect the assistant API.",
    },
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);

  async function send(text: string) {
    const question = text.trim();
    if (!question || loading) return;

    setInput("");
    setMessages((m) => [...m, { role: "user", text: question }]);
    setLoading(true);

    try {
      const response = await askAssistant({
        question,
        caseId: latest?.id,
        reportId: latest?.result?.reportId,
      });
      setMessages((m) => [...m, { role: "ai", text: response.answer }]);
    } catch (error) {
      setMessages((m) => [
        ...m,
        {
          role: "ai",
          text: error instanceof Error ? error.message : "The assistant request failed. Please try again.",
        },
      ]);
    } finally {
      setLoading(false);
    }
  }

   return (
      <>
         <PageHeader
            title="AI Assistant"
            subtitle="Explainability layer over the current report. Questions are sent to the connected assistant API with the selected report context."
         />
         <Card className="glass mx-auto flex h-[65vh] max-w-3xl flex-col rounded-2xl p-5">
            <div className="flex-1 space-y-4 overflow-y-auto pr-1">
              {messages.map((m, i) => (
                 <div key={i} className={`flex gap-3 ${m.role === "user" ? "justify-end" : ""}`}>
                   {m.role === "ai" && (
                      <div className="brand-gradient text-primary-foreground flex h-8 w-8 shrink-0 items-center justify-center rounded-xl">
                        <Bot className="h-4 w-4" />
                      </div>
                   )}
                   <div
                      className={`max-w-[78%] rounded-2xl px-4 py-3 text-sm/6 ${
                        m.role === "user" ? "bg-primary text-primary-foreground" : "bg-secondary"
                      }`}
                   >
                      {m.text}
                   </div>
                   {m.role === "user" && (
                      <div className="bg-secondary flex h-8 w-8 shrink-0 items-center justify-center rounded-xl">
                        <User className="h-4 w-4" />
                      </div>
                   )}
                 </div>
              ))}
            </div>

            <div className="mt-4 flex flex-wrap gap-2">
              {PROMPTS.map((p) => (
                 <button
                   key={p}
                   onClick={() => void send(p)} disabled={loading}
                   className="bg-secondary hover:bg-accent rounded-full px-3 py-1.5 text-xs transition-colors"
                 >
                   {p}
                 </button>
              ))}
            </div>

            <form
              onSubmit={(e) => {
                 e.preventDefault();
                 void send(input);
              }}
              className="mt-3 flex gap-2"
            >
              <input
                 value={input}
                 onChange={(e) => setInput(e.target.value)} disabled={loading}
                 placeholder="Ask about this report…"
                 className="border-border bg-card focus:ring-ring/40 flex-1 rounded-xl border px-4 py-3 text-sm outline-none focus:ring-2"
              />
              <Button type="submit" className="rounded-xl px-4" disabled={loading}>
                 <Send className="h-4 w-4" />
              </Button>
            </form>
         </Card>
      </>
   );
}




