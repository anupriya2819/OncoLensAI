import { createFileRoute } from "@tanstack/react-router";
import { PageHeader } from "@/components/oncolens/PageHeader";
import { Card } from "@/components/ui/card";
import {
   Accordion,
   AccordionContent,
   AccordionItem,
   AccordionTrigger,
} from "@/components/ui/accordion";

export const Route = createFileRoute("/app/help")({
   head: () => ({
      meta: [
         { title: "Help & Guidance — OncoLens AI" },
         {
            name: "description",
            content: "How to register patients, upload slides, interpret heatmaps and generate hospital reports in OncoLens AI.",
         },
         { property: "og:title", content: "Help & Guidance — OncoLens AI" },
         { property: "og:description", content: "Workflow guidance and safety notes for OncoLens AI." },
      ],
   }),
   component: HelpPage,
});

const FAQ = [
   ["How do I run an analysis?", "Register a patient, open New Analysis, fill the sample details, drag in an H&E slide, pass the quality gate, then let the pipeline run."],
   ["Where do the AI results come from?", "No. Only the uploaded image is real. Diagnosis, heatmap, ROI, biomarkers and reportsare returned by the connected backend."],
   ["Why was my slide rejected?", "The quality gate blocks slides that fail resolution, blur, brightness, contrast, staining or tissue-coverage thresholds to prevent unreliable predictions."],
   ["How do I download a report?", "Open any completed report and choose Download PDF — the browser print dialog letsyou save it as a PDF."],
   ["Who can see patient data?", "Access is role-scoped: patients see only their own reports and doctors only their assigned patients."],
];

function HelpPage() {
   return (
      <>
         <PageHeader title="Help" subtitle="Workflow guidance, safety notes and frequently asked questions." />
         <Card className="glass mx-auto max-w-3xl rounded-2xl p-6">
            <Accordion type="single" collapsible>
              {FAQ.map(([q, a]) => (
                 <AccordionItem key={q} value={q!}>
                   <AccordionTrigger className="text-left">{q}</AccordionTrigger>
                   <AccordionContent className="text-muted-foreground text-sm/6">{a}</AccordionContent>
                 </AccordionItem>
              ))}
            </Accordion>
            <p className="text-muted-foreground mt-6 border-t pt-4 text-xs">
              This AI provides decision support only. Final diagnosis remains with the pathologist.
            </p>
         </Card>
      </>
   );
}




