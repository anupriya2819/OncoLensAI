export type Role = "Admin" | "Pathologist" | "Lab Technician" | "Patient";

export interface SessionUser {
  name: string;
  email: string;
  role: Role;
  hospital: string;
}

export interface Patient {
  id: string;
  hospitalId: string;
  name: string;
  age: string;
  gender: string;
  dob: string;
  phone: string;
  email: string;
  address: string;
  notes: string;
  doctor: string;
  createdAt: string;
}

export interface QualityMetric {
  label: string;
  value: number;
  unit?: string;
  ok: boolean;
}

export interface Biomarker {
  name: string;
  priority: "High" | "Medium" | "Low";
  confidence: number;
  recommendation: string;
  rationale: string;
}

export interface Roi {
  x: number;
  y: number;
  w: number;
  h: number;
  score: number;
}

export interface AnalysisResult {
  diagnosis: string;
  confidence: number;
  risk: "Low" | "Moderate" | "High";
  findings: string[];
  biomarkers: Biomarker[];
  rois: Roi[];
  heatmapUrl?: string;
  summary: string;
  ihcCost?: number;
  savings?: number;
  processingSeconds?: number;
  reportId?: string;
  completedAt?: string;
}

export interface CaseRecord {
  id: string;
  sampleId: string;
  patientId: string;
  patientName: string;
  clinicalHistory: string;
  priority: "Routine" | "Urgent" | "Critical";
  doctor: string;
  imageDataUrl: string;
  imageName: string;
  createdAt: string;
  status: "Pending" | "Completed";
  quality: QualityMetric[];
  qualityPassed: boolean;
  result?: AnalysisResult;
}
