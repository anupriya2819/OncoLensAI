import { createContext, useCallback, useContext, useMemo, useState, type ReactNode } from "react";
import type { CaseRecord, Patient, SessionUser } from "./types";
import { isApiConfigured } from "@/api/client";

interface State {
  user: SessionUser | null;
  patients: Patient[];
  cases: CaseRecord[];
  activity: { id: string; text: string; at: string }[];
}

const empty: State = { user: null, patients: [], cases: [], activity: [] };

interface Ctx extends State {
  hydrated: boolean;
  backendConnected: boolean;
  login: (u: SessionUser) => void;
  logout: () => void;
  addPatient: (p: Patient) => void;
  updatePatient: (p: Patient) => void;
  addCase: (c: CaseRecord) => void;
  updateCase: (c: CaseRecord) => void;
  log: (text: string) => void;
}

const StoreContext = createContext<Ctx | null>(null);

/**
 * Frontend-only session store.
 *
 * Persistence and authentication are intentionally not implemented here.
 * The backend developer can replace these operations with API calls without
 * changing the UI components.
 */
export function StoreProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<State>(empty);

  const log = useCallback((text: string) => {
    const item = {
      id: `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      text,
      at: new Date().toISOString(),
    };
    setState((s) => ({ ...s, activity: [item, ...s.activity].slice(0, 40) }));
  }, []);

  const value = useMemo<Ctx>(
    () => ({
      ...state,
      hydrated: true,
      backendConnected: isApiConfigured(),
      login: (user) => setState((s) => ({ ...s, user })),
      logout: () => setState((s) => ({ ...s, user: null })),
      addPatient: (patient) =>
        setState((s) => ({ ...s, patients: [patient, ...s.patients] })),
      updatePatient: (patient) =>
        setState((s) => ({
          ...s,
          patients: s.patients.map((p) => (p.id === patient.id ? patient : p)),
        })),
      addCase: (caseRecord) =>
        setState((s) => ({ ...s, cases: [caseRecord, ...s.cases] })),
      updateCase: (caseRecord) =>
        setState((s) => ({
          ...s,
          cases: s.cases.map((c) => (c.id === caseRecord.id ? caseRecord : c)),
        })),
      log,
    }),
    [state, log],
  );

  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>;
}

export function useStore() {
  const ctx = useContext(StoreContext);
  if (!ctx) throw new Error("useStore must be used inside StoreProvider");
  return ctx;
}
