import { Link, useNavigate, useRouterState } from "@tanstack/react-router";
import {
   Activity,
   BarChart3,
   Bell,
   Bot,
   Building2,
   Cloud,
   FileText,
   GitCompare,
   HelpCircle,
   LayoutDashboard,
   LogOut,
   Menu,
   Search,
   Settings,
   Sparkles,
   UserPlus,
   Users,
} from "lucide-react";
import { useState, type ReactNode } from "react";
import { Brand } from "./Brand";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useStore } from "@/lib/oncolens/store";

const NAV = [
   { to: "/app/dashboard", label: "Dashboard", icon: LayoutDashboard },
   { to: "/app/patients/new", label: "New Patient", icon: UserPlus },
   { to: "/app/patients", label: "Existing Patients", icon: Users },
   { to: "/app/analysis", label: "New Analysis", icon: Sparkles },
   { to: "/app/history", label: "Case History", icon: Activity },
   { to: "/app/compare", label: "Compare Reports", icon: GitCompare },
   { to: "/app/reports", label: "Reports", icon: FileText },
   { to: "/app/analytics", label: "Analytics", icon: BarChart3 },
   { to: "/app/integration", label: "Hospital Integration", icon: Building2 },
   { to: "/app/storage", label: "Cloud Storage", icon: Cloud },
   { to: "/app/assistant", label: "AI Assistant", icon: Bot },
   { to: "/app/settings", label: "Settings", icon: Settings },
   { to: "/app/help", label: "Help", icon: HelpCircle },
] as const;

export function AppShell({ children }: { children: ReactNode }) {
   const { user, logout, activity } = useStore();
   const navigate = useNavigate();
   const [open, setOpen] = useState(false);
   const pathname = useRouterState({ select: (s) => s.location.pathname });

   return (
     <div className="flex min-h-screen w-full">
        <aside
          className={`glass no-print fixed inset-y-0 left-0 z-40 w-[264px] shrink-0 flex-col rounded-none border-r px-4
  py-5 transition-transform duration-300 lg:sticky lg:top-0 lg:flex lg:h-screen lg:translate-x-0 ${
            open ? "flex translate-x-0" : "hidden -translate-x-full lg:flex"
          }`}
        >
          <Link to="/app/dashboard" onClick={() => setOpen(false)}>
            <Brand />
          </Link>
          <nav className="mt-6 flex-1 space-y-1 overflow-y-auto pr-1">
            {NAV.map((item) => {
               const active =
                 pathname === item.to ||
                 (item.to !== "/app/patients" && pathname.startsWith(`${item.to}/`)) ||
                 (item.to === "/app/patients" && pathname.startsWith("/app/patients/") && !pathname.endsWith("/new"));
               return (
                 <Link
                   key={item.to}
                   to={item.to}
                   onClick={() => setOpen(false)}
                   className={`group flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-all d
 uration-200 ${
                     active
                        ? "bg-sidebar-accent text-sidebar-accent-foreground shadow-[var(--shadow-soft)]"
                        : "text-muted-foreground hover:bg-sidebar-accent/50 hover:text-foreground"
                   }`}
                 >



                <item.icon
                  className={`h-[18px] w-[18px] transition-transform group-hover:scale-110 ${active ? "text-primary"
: ""}`}
                   strokeWidth={1.7}
                />
                {item.label}
              </Link>
              );
           })}
         </nav>
         <button
           onClick={() => {
              logout();
              navigate({ to: "/" });
           }}
           className="text-muted-foreground hover:text-destructive mt-3 flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-colors"
         >
           <LogOut className="h-[18px] w-[18px]" strokeWidth={1.7} /> Logout
         </button>
       </aside>

       <div className="flex min-w-0 flex-1 flex-col">
         <header className="glass no-print sticky top-0 z-30 flex items-center gap-3 rounded-none border-x-0 border-t-0 px-4 py-3 lg:px-8">
           <Button
              variant="ghost"
              size="icon"
              className="lg:hidden"
              onClick={() => setOpen((v) => !v)}
              aria-label="Toggle navigation"
           >
              <Menu className="h-5 w-5" />
           </Button>
           <div className="relative hidden max-w-sm flex-1 md:block">
              <Search className="text-muted-foreground pointer-events-none absolute top-1/2 left-3 h-4 w-4 -translate-y-1/2" />
              <input
                 placeholder="Search patients, cases, reports…"
                 className="border-border/70 bg-card/60 focus:ring-ring/40 w-full rounded-xl border py-2 pr-3 pl-9 text-sm outline-none focus:ring-2"
              />
           </div>
           <div className="ml-auto flex items-center gap-3">
              <Badge variant="outline" className="hidden gap-1.5 rounded-full sm:inline-flex">
                 <span className="bg-warn h-1.5 w-1.5 rounded-full" /> Backend not connected
              </Badge>
              <div className="relative">
                 <Bell className="text-muted-foreground h-5 w-5" strokeWidth={1.7} />
                 {activity.length > 0 && (
                    <span className="bg-teal absolute -top-0.5 -right-0.5 h-2 w-2 rounded-full" />
                 )}
              </div>
              <div className="flex items-center gap-2.5">
                 <div className="brand-gradient text-primary-foreground flex h-9 w-9 items-center justify-center rounded-full text-xs font-semibold">
                    {(user?.name ?? "OL")
                      .split(" ")
                      .map((w) => w[0])
                      .join("")
                      .slice(0, 2)
                      .toUpperCase()}
                 </div>
                 <div className="hidden leading-tight sm:block">
                    <p className="text-sm font-semibold">{user?.name ?? "Guest"}</p>
                    <p className="text-muted-foreground text-xs">{user?.role ?? "—"}</p>
                 </div>
              </div>
           </div>
         </header>

         <main className="animate-rise flex-1 px-4 py-6 lg:px-8 lg:py-8">{children}</main>

         <footer className="text-muted-foreground border-border/60 border-t px-4 py-5 text-xs lg:px-8">
           <div className="flex flex-wrap items-center justify-between gap-2">
              <p>Research &amp; Educational Use Only · AI-Assisted Decision Support</p>
              <p>Prototype Version 1.0 · Made by Team SKY</p>



             </div>
          </footer>
       </div>

       {open && (
          <button
             aria-label="Close navigation"
             onClick={() => setOpen(false)}
             className="bg-foreground/20 fixed inset-0 z-30 lg:hidden"
          />
       )}
     </div>
  );
}




