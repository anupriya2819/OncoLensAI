import { Microscope } from "lucide-react";

export function Brand({ compact = false }: { compact?: boolean }) {
   return (
      <div className="flex items-center gap-3">
        <div className="brand-gradient flex h-10 w-10 items-center justify-center rounded-2xl text-primary-foreground shadow-[var(--shadow-soft)]">
           <Microscope className="h-5 w-5" strokeWidth={1.7} />
        </div>
        {!compact && (
           <div className="leading-tight">
             <p className="font-display text-base font-semibold">OncoLens AI</p>
             <p className="text-[11px] tracking-wide text-muted-foreground uppercase">
               Pathology Decision Support
             </p>
           </div>
        )}
      </div>
   );
}




