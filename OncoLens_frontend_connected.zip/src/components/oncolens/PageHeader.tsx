import type { ReactNode } from "react";

export function PageHeader({
  title,
  subtitle,
  action,
}: {
  title: string;
  subtitle?: string;
  action?: ReactNode;
}) {
  return (
     <div className="mb-6 flex flex-wrap items-end justify-between gap-4">
       <div>
         <h1 className="text-2xl font-semibold lg:text-3xl">{title}</h1>
         {subtitle && <p className="text-muted-foreground mt-1.5 max-w-2xl text-sm">{subtitle}</p>}
       </div>
       {action}
     </div>
  );
}




