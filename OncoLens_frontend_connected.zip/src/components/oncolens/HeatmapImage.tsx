import type { Roi } from "@/lib/oncolens/types";

interface Props {
  src: string;
  heatmapSrc?: string | undefined;
  rois?: Roi[] | undefined;
  showHeatmap?: boolean | undefined;
  showRoi?: boolean | undefined;
  className?: string | undefined;
}

export function HeatmapImage({
  src,
  heatmapSrc,
  rois = [],
  showHeatmap = true,
  showRoi = true,
  className = "",
}: Props) {
  return (
    <div className={`relative overflow-hidden rounded-2xl bg-secondary ${className}`}>
      <img
        src={src}
        alt="Uploaded H&E histopathology slide"
        className="block w-full"
      />
      {showHeatmap && heatmapSrc && (
        <img
          src={heatmapSrc}
          alt="Grad-CAM heatmap returned by the backend"
          className="pointer-events-none absolute inset-0 h-full w-full object-cover mix-blend-multiply opacity-75"
        />
      )}
      {showRoi &&
        rois.map((r, i) => (
          <div
            key={`${r.x}-${r.y}-${i}`}
            className="pointer-events-none absolute rounded-lg border-2 border-teal shadow-[0_0_0_1px_rgba(255,255,255,0.55)]"
            style={{
              left: `${r.x}%`,
              top: `${r.y}%`,
              width: `${r.w}%`,
              height: `${r.h}%`,
            }}
          >
            <span className="bg-teal text-teal-foreground absolute -top-0.5 left-0 -translate-y-full rounded-md px-1.5 py-0.5 text-[10px] font-semibold">
              ROI {i + 1} · {r.score}%
            </span>
          </div>
        ))}
      {showHeatmap && !heatmapSrc && (
        <div className="absolute inset-x-3 bottom-3 rounded-xl border border-border/60 bg-background/90 px-3 py-2 text-xs text-muted-foreground backdrop-blur">
          Grad-CAM output will appear here when returned by the backend.
        </div>
      )}
    </div>
  );
}
