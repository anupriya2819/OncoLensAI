import { apiRequest } from "./client";
import { API_ENDPOINTS } from "./endpoints";

export interface AssistantRequest {
  question: string;
  caseId?: string | undefined;
  reportId?: string | undefined;
}

export interface AssistantResponse {
  answer: string;
}

export function askAssistant(request: AssistantRequest) {
  return apiRequest<AssistantResponse>(API_ENDPOINTS.assistant, {
    method: "POST",
    body: JSON.stringify(request),
    timeoutMs: 60_000,
  });
}
