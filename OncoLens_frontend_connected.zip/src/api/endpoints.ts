/**
 * Backend contract placeholders.
 *
 * Change ONLY these paths if the backend developer uses different routes.
 * The request/response shapes are documented in BACKEND_HANDOFF.md.
 */
export const API_ENDPOINTS = {
  quality: "/v1/analysis/quality",
  analysis: "/v1/analysis",
  assistant: "/v1/assistant",
  report: "/v1/reports",
} as const;
