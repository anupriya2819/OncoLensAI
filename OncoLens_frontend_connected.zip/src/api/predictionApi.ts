import { apiRequest } from "./client";
import { API_ENDPOINTS } from "./endpoints";
import type { AnalysisResult, QualityMetric } from "@/lib/oncolens/types";

export interface QualityAssessmentResponse {
  metrics: QualityMetric[];
  passed: boolean;
}

export interface AnalysisRequest {
  sampleId: string;
  patientId: string;
  clinicalHistory: string;
  priority: "Routine" | "Urgent" | "Critical";
  doctor: string;
  image: File;
}

export async function assessImageQuality(image: File): Promise<QualityAssessmentResponse> {
  const formData = new FormData();
  formData.append("image", image);

  return apiRequest<QualityAssessmentResponse>(API_ENDPOINTS.quality, {
    method: "POST",
    body: formData,
    timeoutMs: 120_000,
  });
}

export async function runAnalysis(request: AnalysisRequest): Promise<AnalysisResult> {
  const formData = new FormData();
  formData.append("image", request.image);
  formData.append("sampleId", request.sampleId);
  formData.append("patientId", request.patientId);
  formData.append("clinicalHistory", request.clinicalHistory);
  formData.append("priority", request.priority);
  formData.append("doctor", request.doctor);

  return apiRequest<AnalysisResult>(API_ENDPOINTS.analysis, {
    method: "POST",
    body: formData,
    timeoutMs: 300_000,
  });
}
