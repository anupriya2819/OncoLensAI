import { apiRequest } from "./client";
import { API_ENDPOINTS } from "./endpoints";

export async function getReport(reportId: string) {
  return apiRequest<unknown>(`${API_ENDPOINTS.report}/${encodeURIComponent(reportId)}`, {
    method: "GET",
  });
}
