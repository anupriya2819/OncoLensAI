const baseUrl = (import.meta.env['VITE_API_BASE_URL'] as string | undefined)?.replace(/\/+$/, "");

export class ApiError extends Error {
  status?: number | undefined;
  constructor(message: string, status?: number) {
    super(message);
    this.name = "ApiError";
    this.status = status;
  }
}

export function isApiConfigured() {
  return Boolean(baseUrl);
}

export async function apiRequest<T>(
  path: string,
  options: RequestInit & { timeoutMs?: number } = {},
): Promise<T> {
  if (!baseUrl) {
    throw new ApiError(
      "Backend API is not configured. Set VITE_API_BASE_URL in the frontend environment.",
    );
  }

  const { timeoutMs = 120_000, ...requestInit } = options;
  const controller = new AbortController();
  const timeout = window.setTimeout(() => controller.abort(), timeoutMs);

  try {
    const headers = new Headers(requestInit.headers);
    if (!(requestInit.body instanceof FormData) && requestInit.body != null) {
      headers.set("Content-Type", "application/json");
    }
    // Free Ngrok tunnels show a browser warning unless API requests include this header.
    if (baseUrl.includes("ngrok-free")) {
      headers.set("ngrok-skip-browser-warning", "true");
    }
    const response = await fetch(`${baseUrl}${path}`, {
      ...requestInit,
      headers,
      signal: controller.signal,
    });

    const contentType = response.headers.get("content-type") ?? "";
    const body = contentType.includes("application/json")
      ? await response.json()
      : await response.text();

    if (!response.ok) {
      const detail =
        typeof body === "object" && body !== null && "message" in body
          ? String((body as { message?: unknown }).message)
          : typeof body === "object" && body !== null && "detail" in body
            ? String((body as { detail?: unknown }).detail)
            : `Request failed with status ${response.status}.`;
      throw new ApiError(detail, response.status);
    }

    return body as T;
  } catch (error) {
    if (error instanceof ApiError) throw error;
    if (error instanceof DOMException && error.name === "AbortError") {
      throw new ApiError("The backend request timed out. Please try again.");
    }
    throw new ApiError("Unable to reach the backend API. Check the connection and try again.");
  } finally {
    window.clearTimeout(timeout);
  }
}

export { baseUrl };
